//
//  ViewController.m
//  customDelegate
//
//  Created by TsaiHsueh Hsin on 2015/7/1.
//  Copyright (c) 2015年 MyBigDay. All rights reserved.
//

#import "ViewController.h"
#import "DetailViewController.h"
@interface ViewController ()<DetailViewControllerDelegate>
@property (weak, nonatomic) IBOutlet UILabel *label;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)next:(id)sender {
    DetailViewController * detailVC = [self.storyboard instantiateViewControllerWithIdentifier:@"DetailViewController"];
    detailVC.delegate = self;
    [self showViewController:detailVC sender:nil];
}

-(void)didPressOKButton {
    NSLog(@"hihihih");
}

-(void)textFieldHasBeenEditing:(NSString *)text{
    
}




@end
