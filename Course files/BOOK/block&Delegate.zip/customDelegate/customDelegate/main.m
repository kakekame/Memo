//
//  main.m
//  customDelegate
//
//  Created by TsaiHsueh Hsin on 2015/7/1.
//  Copyright (c) 2015年 MyBigDay. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
