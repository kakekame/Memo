//
//  DetailViewController.h
//  customDelegate
//
//  Created by TsaiHsueh Hsin on 2015/7/1.
//  Copyright (c) 2015年 MyBigDay. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol DetailViewControllerDelegate
-(void)didPressOKButton;
-(void)textFieldHasBeenEditing:(NSString*)text;
@end


@interface DetailViewController : UIViewController
@property (weak,nonatomic) id<DetailViewControllerDelegate> delegate;
@end
