//
//  ViewController.h
//  customDelegate
//
//  Created by TsaiHsueh Hsin on 2015/7/1.
//  Copyright (c) 2015年 MyBigDay. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface ViewController : UIViewController
@end

