//
//  BViewController.m
//  BlockPassingValue
//
//  Created by TsaiHsueh Hsin on 2015/7/29.
//  Copyright (c) 2015年 Glee. All rights reserved.
//

#import "BViewController.h"
@interface BViewController()<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextField *textField;
@end
@implementation BViewController
-(void)viewWillDisappear:(BOOL)animated
{
    [self.view endEditing:YES];
}

-(void)downloadJsonFromServer:(void (^)(NSError *))completionBlock
{
    /*利用 NSURLSession 去跟伺服器下載資料*/
    
    /*宣告一個 NSError*/
    
    NSError * error = nil;
    
    /*如果下載過程中，發生任何問題，把錯誤報告寫到 NSError 中*/
    
    /*下載完畢後，執行 block 上面的程式碼*/
    
    if (completionBlock) {
        /*並把錯誤報告餵進去*/
        completionBlock(error);
    }
}

-(void)textFieldDidEndEditing:(UITextField *)textField
{
//    self.block(textField.text);
    self.block(textField.text);
}
@end
