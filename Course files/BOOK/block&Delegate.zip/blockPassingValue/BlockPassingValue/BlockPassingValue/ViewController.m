//
//  ViewController.m
//  BlockPassingValue
//
//  Created by TsaiHsueh Hsin on 2015/7/29.
//  Copyright (c) 2015年 Glee. All rights reserved.
//

#import "ViewController.h"
#import "BViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UILabel *label;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)nextViewController:(id)sender {
    BViewController * viewcontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"BViewController"];
    viewcontroller.block = ^void(NSString*response){
        [self.label setText:response];
    };
    
    
    [self.navigationController pushViewController:viewcontroller animated:YES];
}
@end
