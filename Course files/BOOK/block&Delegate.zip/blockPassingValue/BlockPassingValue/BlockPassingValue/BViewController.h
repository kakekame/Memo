//
//  BViewController.h
//  BlockPassingValue
//
//  Created by TsaiHsueh Hsin on 2015/7/29.
//  Copyright (c) 2015年 Glee. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^SendStringBack)(NSString*string);

@interface BViewController : UIViewController
@property (nonatomic,strong) SendStringBack block;

-(void)downloadJsonFromServer:(void(^)(NSError*error))completionBlock;

-(float)calcBMI:(int)height andWeight:(int)weight;
@end
