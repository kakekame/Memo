//
//  AppDelegate.h
//  BlockPassingValue
//
//  Created by TsaiHsueh Hsin on 2015/7/29.
//  Copyright (c) 2015年 Glee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

