//
//  main.m
//  HelloMyBarCode
//
//  Created by Kent Liu on 13/12/29.
//  Copyright (c) 2013年 Kent Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
