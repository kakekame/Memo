<?php
	//header("content-type:image/png");
	//header("content-disposition:attachment; filename=1.png");
	//echo file_get_contents("image1.jpg");
	
	header("location:https://www.google.com.tw/");
?>