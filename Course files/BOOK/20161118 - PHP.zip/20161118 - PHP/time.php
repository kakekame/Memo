<?php
	echo time();
	echo "<br>";
	echo date("m/d/Y H:i:s");
	echo "<br>";
	echo strtotime("2016-01-01 23:10:00");
	echo "<br>";
	echo date("m/d/Y A h:i:s",1451661000);
	exit();
?>