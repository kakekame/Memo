function doFirst(){
	document.querySelector('p').onclick = talk;
}
function talk(){
	alert('hi~');
}
window.addEventListener('load',doFirst,false);
//window.onload = doFirst;