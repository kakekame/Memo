function doFirst(){
	var x = document.getElementById('canvas');
	var canvas = x.getContext('2d');

	// canvas.textBaseline = 'alphabetic';
	canvas.shadowOffsetX = 5;
	canvas.shadowOffsetY = 5;
	canvas.shadowColor = 'green';
	canvas.shadowBlur = 5;

	canvas.font = 'bold 70px Tahoma';
	canvas.fillText('Google',100,100);

	// canvas.moveTo(100,100);
	// canvas.lineTo(280,100);
	// canvas.stroke();

	canvas.shadowOffsetX = 0;
	canvas.shadowOffsetY = 0;
	canvas.shadowColor = 'green';
	canvas.shadowBlur = 15;

	canvas.fillStyle = '#fff';
	canvas.fillText('Google',100,200);	

	canvas.shadowOffsetX = 8;
	canvas.shadowOffsetY = -8;
	canvas.shadowColor = '#000';
	canvas.shadowBlur = 10;

	canvas.fillStyle = '';
	canvas.fillText('Google',100,300);	
}
window.addEventListener('load',doFirst,false);