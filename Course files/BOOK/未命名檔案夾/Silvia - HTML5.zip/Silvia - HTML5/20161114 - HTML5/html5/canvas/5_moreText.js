function doFirst(){
	var x = document.getElementById('canvas');
	var canvas = x.getContext('2d');

	
}
window.addEventListener('load',doFirst,false);