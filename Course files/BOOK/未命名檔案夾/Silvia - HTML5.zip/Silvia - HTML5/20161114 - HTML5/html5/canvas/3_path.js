function doFirst(){
	var x = document.getElementById('canvas');
	var canvas = x.getContext('2d');

	canvas.moveTo(100,100);
	canvas.lineTo(200,200);
	canvas.lineTo(350,50);
	canvas.lineTo(450,100);
	canvas.closePath();

	canvas.strokeStyle = 'red';
	canvas.lineWidth = 5;

	canvas.fillStyle = '#ccc';

	canvas.stroke();
	canvas.fill();
}
window.addEventListener('load',doFirst,false);