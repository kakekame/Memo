function doFirst(){
	var x = document.getElementById('canvas');
	var canvas = x.getContext('2d');

	canvas.lineWidth = 5;
	canvas.strokeStyle = 'red';

	canvas.arc(200,200,150,0,2*Math.PI,false);
	canvas.stroke();	

	canvas.beginPath();
	
	canvas.translate(200,200);

	canvas.moveTo(0,0);
	canvas.lineTo(0,-130);

	canvas.stroke();
	// canvas.beginPath();
	// canvas.moveTo(200,200);
	// canvas.lineTo(200,70);
	// canvas.stroke();	
}
window.addEventListener('load',doFirst,false);