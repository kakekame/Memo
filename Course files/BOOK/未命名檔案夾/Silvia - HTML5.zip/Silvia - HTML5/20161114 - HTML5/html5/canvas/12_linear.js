function doFirst(){
	var x = document.getElementById('canvas');
	var canvas = x.getContext('2d');

	var gradient = canvas.createLinearGradient(100,250,600,250);
	gradient.addColorStop(0,'#f00');
	gradient.addColorStop(1,'#000');
	gradient.addColorStop(0.5,'#ddd');

	canvas.fillStyle = gradient;
	canvas.fillRect(100,100,500,300);
}
window.addEventListener('load',doFirst,false);