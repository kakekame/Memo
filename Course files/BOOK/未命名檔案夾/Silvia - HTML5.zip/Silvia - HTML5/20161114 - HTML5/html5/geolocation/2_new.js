function doFirst(){
	if(navigator.geolocation){
		alert('Support!');
		navigator.geolocation.getCurrentPosition(succCallback,errorCallback,{
			timeout:100000,
			enableHighAccuracy: false,
			maximumAge: 0
		});
	}else{
		alert('NO Support!');
	}
}

function succCallback(e){
	var lati = e.coords.latitude;
	var longi = e.coords.longitude;

	document.getElementById('position').innerHTML = '緯度:'+lati+'<br>經度:'+longi;
}

function errorCallback(e){
	// document.getElementById('position').innerHTML = 'Code:'+e.code+'<br>Message:'+e.message;
	alert('Code:'+e.code+'\nMessage:'+e.message);
}
window.addEventListener('load',doFirst,false);




