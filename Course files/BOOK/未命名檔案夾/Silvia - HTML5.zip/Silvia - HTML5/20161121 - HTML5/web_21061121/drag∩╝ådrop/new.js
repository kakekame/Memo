function doFirst(){
	//先跟HTML畫面產生關聯,再建事件聆聽的功能
	image = document.getElementById('image');
	image.addEventListener('dragstart',startDrag,false);
	image.addEventListener('dragend',endDrag,false);

	leftbox = document.getElementById('leftbox');
//	leftbox.addEventListener('dragenter',function(e){e.preventDefault();},false);
	leftbox.addEventListener('dragover',function(e){e.preventDefault();},false);
	leftbox.addEventListener('drop',dropped,false);

}
function startDrag(e){
	var data = '<img src="../../images/pig.jpg">';
	e.dataTransfer.setData('image/jpeg',data);
}
function endDrag(){
	image.style.visibility = 'hidden';
}
function dropped(e){
	e.preventDefault();
	leftbox.innerHTML = e.dataTransfer.getData('image/jpeg');
}
window.addEventListener('load',doFirst,false);



