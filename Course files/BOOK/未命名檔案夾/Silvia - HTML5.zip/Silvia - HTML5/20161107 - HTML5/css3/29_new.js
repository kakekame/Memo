function doFirst(){
	//先跟ＨＴＭＬ畫面產生關聯
	image = document.getElementById('image');
	playButton = document.getElementById('playButton');
	pauseButton = document.getElementById('pauseButton');

	//再建事件聆聽的功能
	playButton.addEventListener('click',imageGo,false);
	pauseButton.addEventListener('click',imageStop,false);
}
function imageGo(){
	image.style.animationPlayState = 'running';
}
function imageStop(){
	image.style.animationPlayState = 'paused';
}
window.addEventListener('load',doFirst,false);