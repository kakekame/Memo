function doFirst(){
	//先跟ＨＴＭＬ畫面產生關聯,再建事件聆聽的功能
	document.querySelector('button').onclick = talk;
}

function talk(){
	alert('hi~');
}
window.addEventListener('load',doFirst,false);