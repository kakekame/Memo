// var ans = confirm('hi~');			
// alert(ans);

function doFirst(){
	var feedback = document.getElementById('feedback');
	feedback.innerHTML = '<h1 style="color:red;">hi~</h1>';
}
window.addEventListener('load',doFirst,false);