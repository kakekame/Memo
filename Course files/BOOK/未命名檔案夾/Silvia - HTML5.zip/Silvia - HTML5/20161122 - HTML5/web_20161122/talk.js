function doFirst(){
	var divTalk = document.createElement('div');
	divTalk.className = 'talk';
	divTalk.innerHTML = 'skdflhg dfg fdgdfg sdfg<br>jsld dgdgdfg dfg';

	var skin = document.getElementById('skin');
	skin.appendChild(divTalk);

	var image = document.createElement('img');
	image.src = '../images/washDrawing/005.JPG';
	image.width = 300;

//	skin.appendChild(image);
	skin.insertBefore(image, skin.firstChild);
}
window.addEventListener('load',doFirst,false);