<h2>新增資料</h2>
<form action="insert.php" method="post" enctype="multipart/form-data">
	標題：<input type="text" name="title"><br>
	來源：<input type="text" name="source"><br>
	時間：<input type="text" name="time"><br>
	內容：<textarea name="description" style="width:300px;height:150px;"></textarea><br>
	<input type="submit" value="儲存">
</form>