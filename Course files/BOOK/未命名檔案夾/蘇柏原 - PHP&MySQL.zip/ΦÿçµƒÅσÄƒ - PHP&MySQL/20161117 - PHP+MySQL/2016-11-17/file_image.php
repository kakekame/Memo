<?php
	echo file_get_contents("image1.jpg");
?>