<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
<pre>
<?php
	$x=10;
	$y="10";
	if($x===$y){
		echo "相等";
	}elseif($x>$y){
		echo "X大於Y";
	}elseif($x<$y){
		echo "X小於Y";
	}else{
		echo "未知";
	}
?>
</pre>
</body>
</html>