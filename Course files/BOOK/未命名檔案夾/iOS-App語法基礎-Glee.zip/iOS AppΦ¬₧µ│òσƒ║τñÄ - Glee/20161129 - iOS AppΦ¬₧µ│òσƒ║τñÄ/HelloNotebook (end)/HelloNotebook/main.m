//
//  main.m
//  HelloNotebook
//
//  Created by XueXin Tsai on 2016/11/29.
//  Copyright © 2016年 XueXin Tsai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
