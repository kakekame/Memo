//
//  AppDelegate.h
//  HelloUISlider
//
//  Created by XueXin Tsai on 2016/11/10.
//  Copyright © 2016年 XueXin Tsai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

