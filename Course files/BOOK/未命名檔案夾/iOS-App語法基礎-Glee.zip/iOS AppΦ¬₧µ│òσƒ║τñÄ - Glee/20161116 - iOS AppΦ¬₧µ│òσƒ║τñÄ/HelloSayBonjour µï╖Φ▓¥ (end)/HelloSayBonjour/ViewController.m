//
//  ViewController.m
//  HelloSayBonjour
//
//  Created by 123APP on 2016/11/15.
//  Copyright © 2016年 com.glee. All rights reserved.
//

#import "ViewController.h"
#import "BonjourViewController.h"
@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *nameTextField;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    NSLog(@"第一頁的物件正在跑 viewDidLoad");
}

-(void)viewWillAppear:(BOOL)animated {
    NSLog(@"第一頁的物件正在跑 viewWillAppear");
}

-(void)viewDidAppear:(BOOL)animated {
    NSLog(@"第一頁的物件正在跑 viewDidAppear");
}

-(void)viewWillDisappear:(BOOL)animated {
    NSLog(@"第一頁的物件正在跑 viewWillDisappear");
}

-(void)viewDidDisappear:(BOOL)animated {
    NSLog(@"第一頁的物件正在跑 viewDidDisappear");
}

//逃生門的方法
-(IBAction)exitToPageOne:(UIStoryboardSegue*)segue{
    //裡面可以什麼都不要寫，沒有問題！！
    //但是逃生門的方法，一定要回傳 IBAction
    //一定要代入 UIStoryboardSegue的物件當作參數
}


// 為轉換而準備的方法 （其實是覆寫方法 override）
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    // 我想拿到第二頁的物件
    BonjourViewController * second = segue.destinationViewController;
    // 我想拿到使用者輸入的文字
    NSString * userType = self.nameTextField.text;
    // 將文字帶給第二頁的物件
    second.name = userType;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
