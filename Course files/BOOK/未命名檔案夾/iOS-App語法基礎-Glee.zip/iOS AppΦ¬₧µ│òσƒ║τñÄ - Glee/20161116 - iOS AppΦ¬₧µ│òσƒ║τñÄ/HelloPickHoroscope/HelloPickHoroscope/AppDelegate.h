//
//  AppDelegate.h
//  HelloPickHoroscope
//
//  Created by 123APP on 2016/11/16.
//  Copyright © 2016年 com.glee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

