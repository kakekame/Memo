//
//  ViewController.m
//  HelloPickHoroscope
//
//  Created by 123APP on 2016/11/16.
//  Copyright © 2016年 com.glee. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UIPickerViewDelegate,UIPickerViewDataSource>
@property NSArray * stars;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
//    self.stops = @[@"南港",@"台北",@"板橋",@"桃園",@"新竹",@"苗栗",@"台中"];
    
    //讀取plist資料
    //找到data.plist的路徑
    NSString * filepath = [[NSBundle mainBundle] pathForResource:@"data" ofType:@"plist"];
    //將路徑內的資料讀取成 NSArray
    self.stars = [[NSArray alloc] initWithContentsOfFile:filepath];
}

#pragma mark - PickerView的DataSource方法
// PickerView 裡需要幾個欄
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

// 每個欄裡需要幾個列
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return self.stars.count;
}

// 每個列要呈現的文字內容
-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    NSLog(@"目前的列是:%ld",row);
    return self.stars[row][@"name"];
}

// 回應使用者目前滑動到的欄與列
//-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
//{
//    NSLog(@"使用者滑到了第%ld個欄與第%ld列",component,row);
//    if (component == 0) {
//        NSString * departure = self.stops[row];
//        NSLog(@"出發站：%@",departure);
//    } else {
//        NSString * destination = self.stops[row];
//        NSLog(@"到達站：%@",destination);
//    }
//}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
