//
//  Player.m
//  Playground
//
//  Created by XueXin Tsai on 2016/11/9.
//  Copyright © 2016年 XueXin Tsai. All rights reserved.
//

#import "Player.h"
@implementation Player
-(void)perform:(NSString *)skill{
//    //先檢查receiver（聽話者）的身上有沒有要發動的技能名稱
//    if ([self.skills containsObject:skill]) {
//        //如果有，發動技能
//        NSLog(@"發動%@",skill);
//    } else {
//        //如果沒有，提示找不到技能
//        NSLog(@"沒有習得這項技能");
//    }
    
}



@end
