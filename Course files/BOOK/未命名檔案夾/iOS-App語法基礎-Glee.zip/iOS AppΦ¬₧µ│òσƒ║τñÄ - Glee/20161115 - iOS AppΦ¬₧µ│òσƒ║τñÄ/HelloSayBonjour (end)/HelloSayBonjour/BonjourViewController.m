//
//  BonjourViewController.m
//  HelloSayBonjour
//
//  Created by 123APP on 2016/11/15.
//  Copyright © 2016年 com.glee. All rights reserved.
//

#import "BonjourViewController.h"

@interface BonjourViewController ()
@property (weak, nonatomic) IBOutlet UILabel *displayNameLabel;

@end

@implementation BonjourViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    // 將上一頁拿到的文字 顯示在畫面上
    self.displayNameLabel.text = self.name;
    NSLog(@"第二頁的物件正在跑 viewDidLoad");
}

-(void)viewWillAppear:(BOOL)animated {
    NSLog(@"第二頁的物件正在跑 viewWillAppear");
}

-(void)viewDidAppear:(BOOL)animated {
    NSLog(@"第二頁的物件正在跑 viewDidAppear");
}

-(void)viewWillDisappear:(BOOL)animated {
    NSLog(@"第二頁的物件正在跑 viewWillDisappear");
}

-(void)viewDidDisappear:(BOOL)animated {
    NSLog(@"第二頁的物件正在跑 viewDidDisappear");
}

- (IBAction)backToLast:(UIButton *)sender {
    //打散這一頁（第二頁）  
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
