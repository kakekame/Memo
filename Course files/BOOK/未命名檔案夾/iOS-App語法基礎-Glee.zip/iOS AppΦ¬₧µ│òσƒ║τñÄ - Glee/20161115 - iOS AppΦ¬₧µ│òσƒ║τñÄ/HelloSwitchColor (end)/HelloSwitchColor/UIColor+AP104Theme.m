//
//  UIColor+AP104Theme.m
//  HelloSwitchColor
//
//  Created by 123APP on 2016/11/15.
//  Copyright © 2016年 com.glee. All rights reserved.
//

#import "UIColor+AP104Theme.h"

@implementation UIColor (AP104Theme)
+(UIColor *)enterpriseColor
{
    // Category ---> 在Swift叫做Extension
    UIColor * c = [UIColor colorWithRed:40.0/255.0 green:50.0/255.0 blue:60.0/255.0 alpha:1.0];
    return c;
}
@end
