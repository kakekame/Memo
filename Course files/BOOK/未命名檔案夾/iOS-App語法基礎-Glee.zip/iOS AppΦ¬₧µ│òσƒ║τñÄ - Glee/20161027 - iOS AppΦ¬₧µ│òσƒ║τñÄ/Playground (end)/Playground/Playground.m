//
//  Playground.m
//  Playground
//
//  Created by XueXin Tsai on 2016/10/27.
//  Copyright © 2016年 XueXin Tsai. All rights reserved.
//

#import "Playground.h"

@implementation Playground
-(void)start {
    NSLog(@"hello");
}
@end
