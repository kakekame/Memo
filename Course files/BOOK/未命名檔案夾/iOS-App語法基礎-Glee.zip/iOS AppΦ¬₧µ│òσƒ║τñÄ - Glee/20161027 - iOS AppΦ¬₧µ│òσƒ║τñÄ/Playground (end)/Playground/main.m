//
//  main.m
//  Playground
//
//  Created by XueXin Tsai on 2016/10/27.
//  Copyright © 2016年 XueXin Tsai. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Playground.h"
int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Playground * p = [Playground new];
        [p start];
    }
    return 0;
}
