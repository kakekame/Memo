//
//  ViewController.h
//  HelloAdvancedImageView
//
//  Created by Kent Liu on 2016/3/8.
//  Copyright © 2016年 Kent Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

