//
//  SpriteKitEasingSwift.h
//  SpriteKitEasingSwift
//
//  Created by CraigGrummitt on 8/08/2014.
//  Copyright (c) 2014 CraigGrummitt. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SpriteKitEasingSwift.
FOUNDATION_EXPORT double SpriteKitEasingSwiftVersionNumber;

//! Project version string for SpriteKitEasingSwift.
FOUNDATION_EXPORT const unsigned char SpriteKitEasingSwiftVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SpriteKitEasingSwift/PublicHeader.h>


