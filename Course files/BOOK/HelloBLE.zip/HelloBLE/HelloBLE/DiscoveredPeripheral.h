//
//  DiscoveredPeripheral.h
//  HelloBLE
//
//  Created by Kent Liu on 2015/8/12.
//  Copyright (c) 2015年 Kent Liu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

@interface DiscoveredPeripheral : NSObject

@property (nonatomic,strong) CBPeripheral *peripheral;
@property (nonatomic,assign) NSInteger lastRSSI;
@property (nonatomic,strong) NSDate *lastSeenDateTime;

@end
