//
//  MasterViewController.h
//  HelloBLE
//
//  Created by Kent Liu on 2015/8/10.
//  Copyright (c) 2015年 Kent Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DetailViewController;

@interface DiscoveryTableViewController : UITableViewController

@property (strong, nonatomic) DetailViewController *detailViewController;


@end

