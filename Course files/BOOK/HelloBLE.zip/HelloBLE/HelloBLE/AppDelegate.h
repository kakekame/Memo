//
//  AppDelegate.h
//  HelloBLE
//
//  Created by Kent Liu on 2015/8/10.
//  Copyright (c) 2015年 Kent Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

