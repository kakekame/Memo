//
//  DiscoveredPeripheral.m
//  HelloBLE
//
//  Created by Kent Liu on 2015/8/12.
//  Copyright (c) 2015年 Kent Liu. All rights reserved.
//

#import "DiscoveredPeripheral.h"

@implementation DiscoveredPeripheral

@end
