//
//  PeripheralModeViewController.m
//  HelloBLE
//
//  Created by Kent Liu on 2015/8/10.
//  Copyright (c) 2015年 Kent Liu. All rights reserved.
//

#import "PeripheralModeViewController.h"
#import <CoreBluetooth/CoreBluetooth.h>

#define SERVICE_UUID @"888A39F4-73F5-4BC4-A12F-17D1AD07A961"
#define CHARACTERISTIC_UUID @"88890F7E-DB05-467E-8757-72F6FAEB13D4"
#define PERIPHERAL_NAME @"KentPeripheral"

@interface PeripheralModeViewController () <CBPeripheralManagerDelegate,UITextFieldDelegate>
{
    CBPeripheralManager *peripheralManager;
    CBMutableCharacteristic *myCharacteristic;
    
}
@property (weak, nonatomic) IBOutlet UITextField *inputTextField;
@property (weak, nonatomic) IBOutlet UITextView *logTextView;
@property (weak, nonatomic) IBOutlet UISwitch *advertisingSwitch;

@end

@implementation PeripheralModeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    peripheralManager = [[CBPeripheralManager alloc] initWithDelegate:self queue:nil];
    
    _inputTextField.delegate = self;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) showSimpleAlert:(NSString*) title message:(NSString*) message {
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *ok=[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
    
    [alert addAction:ok];
    
    [self presentViewController:alert animated:true completion:nil];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (IBAction)advertisingSwitchValueChanged:(id)sender {
    
    if(_advertisingSwitch.on)
    {
        // Note! It must be a Array
        CBUUID *uuid = [CBUUID UUIDWithString:SERVICE_UUID];
        NSArray *UUIDs = @[uuid];
        
        NSDictionary *info = @{CBAdvertisementDataServiceUUIDsKey : UUIDs,
                               CBAdvertisementDataLocalNameKey : PERIPHERAL_NAME};
        [peripheralManager startAdvertising:info];
        
        if([peripheralManager isAdvertising])
        {
            NSLog(@"Advisiting started.");
        }
    }
    else
    {
        [peripheralManager stopAdvertising];
    }
    
}

- (void) sendText:(NSString*)text central:(CBCentral*) central {
    
    NSData *data = [text dataUsingEncoding:NSUTF8StringEncoding];
    
    NSLog(@"Sending: %@",text);
    
    if(central == nil)
    {
        [peripheralManager updateValue:data forCharacteristic:myCharacteristic onSubscribedCentrals:nil];
    }
    else
    {
        [peripheralManager updateValue:data forCharacteristic:myCharacteristic onSubscribedCentrals:@[central]];
    }
}

#pragma mark - UITextFieldDelegate Methods

- (BOOL) textFieldShouldReturn:(UITextField *)textField {
    
    [textField resignFirstResponder];
    
    if(textField.text.length > 0)
    {
        NSString *contentWillSend = [NSString stringWithFormat:@"[%@] %@ \n",PERIPHERAL_NAME,textField.text];
        
        [self sendText:contentWillSend central:nil];
        
        _logTextView.text = [NSString stringWithFormat:@"%@%@",contentWillSend,_logTextView.text];
    }
    
    return false;
}

#pragma mark - CBPeripheralManagerDelegate Methods

- (void) peripheralManagerDidUpdateState:(CBPeripheralManager *)peripheral {
    
    CBPeripheralManagerState state = peripheral.state;
    
    if(state != CBPeripheralManagerStatePoweredOn)
    {
        NSString *message = [NSString stringWithFormat:@"BLE is not available(error: %ld)",(long)state];
        
        [self showSimpleAlert:nil message:message];
    }
    else
    {
        // Preparing
        CBUUID *uuidCharacteristic = [CBUUID UUIDWithString:CHARACTERISTIC_UUID];
        CBUUID *uuidService = [CBUUID UUIDWithString:SERVICE_UUID];
        
        CBCharacteristicProperties properties = CBCharacteristicPropertyNotify |
        CBCharacteristicPropertyRead |
        CBCharacteristicPropertyWrite;
        
        CBAttributePermissions permissions = CBAttributePermissionsReadable | CBAttributePermissionsWriteable;
        
        myCharacteristic = [[CBMutableCharacteristic alloc] initWithType:uuidCharacteristic properties:properties value:nil permissions:permissions];
        
        CBMutableService *myService = [[CBMutableService alloc] initWithType:uuidService primary:true];
        
        myService.characteristics = @[myCharacteristic];
        
        [peripheralManager addService:myService];
    }
    
}

- (void)peripheralManager:(CBPeripheralManager *)peripheral central:(CBCentral *)central didSubscribeToCharacteristic:(CBCharacteristic *)characteristic {
    
    NSString *subscribeInfo = [NSString stringWithFormat:@"* Central subscribed(UUID: %@),max update length is %ld.\n",central.identifier.UUIDString,(unsigned long)central.maximumUpdateValueLength];
    
    NSLog(@"%@",subscribeInfo);
    
    _logTextView.text = [NSString stringWithFormat:@"%@%@",subscribeInfo,_logTextView.text];
    
    // Say Hello to Central
    
    NSString *hello = [NSString stringWithFormat:@"[%@] Hi,I am %@. (Total:%ld)\n",PERIPHERAL_NAME,PERIPHERAL_NAME,(unsigned long)myCharacteristic.subscribedCentrals.count];
    
    NSLog(@"%@",hello);
    
    [self sendText:hello central:central];
    
    _logTextView.text = [NSString stringWithFormat:@"%@%@",hello,_logTextView.text];
}

- (void)peripheralManager:(CBPeripheralManager *)peripheral central:(CBCentral *)central didUnsubscribeFromCharacteristic:(CBCharacteristic *)characteristic {
    
    _logTextView.text = [NSString stringWithFormat:@"%@%@",@"* Central unsubscribed.\n",_logTextView.text];
}

- (void) peripheralManagerIsReadyToUpdateSubscribers:(CBPeripheralManager *)peripheral {
    // is ready to send next data
}

- (void) peripheralManager:(CBPeripheralManager *)peripheral didReceiveWriteRequests:(NSArray *)requests {
    
    NSLog(@"didReceiveWriteRequests");
    
    for(CBATTRequest *tmp in requests)
    {
        
        NSString *content = [[NSString alloc] initWithData:tmp.value encoding:NSUTF8StringEncoding];
        
        if(content != nil)
        {
            _logTextView.text = [NSString stringWithFormat:@"%@%@",content,_logTextView.text];
            [self sendText:content central:nil];
        }
        
        [peripheralManager respondToRequest:tmp withResult:CBATTErrorSuccess];
    }
}

@end





