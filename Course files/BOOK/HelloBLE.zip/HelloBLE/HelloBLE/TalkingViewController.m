//
//  TalkingViewController.m
//  HelloBLE
//
//  Created by Kent Liu on 2015/8/12.
//  Copyright (c) 2015年 Kent Liu. All rights reserved.
//

#import "TalkingViewController.h"

#define CENTRAL_NAME @"KentCentral"

@interface TalkingViewController () <UITextFieldDelegate,CBPeripheralDelegate>
@property (weak, nonatomic) IBOutlet UITextField *inputTextField;
@property (weak, nonatomic) IBOutlet UITextView *logTextView;

@end

@implementation TalkingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    _targetPeripheral.delegate = self;
    [_targetPeripheral setNotifyValue:true forCharacteristic:_targetCharactistic];
    
    _inputTextField.delegate = self;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) viewDidDisappear:(BOOL)animated {
    
    [super viewDidDisappear:animated];
    
    [_targetPeripheral setNotifyValue:false forCharacteristic:_targetCharactistic];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - UITextFieldDelegate Methods

- (BOOL) textFieldShouldReturn:(UITextField *)textField {
    
    [textField resignFirstResponder];
    
    if(textField.text.length > 0)
    {
        NSString *contentWillSend = [NSString stringWithFormat:@"[%@] %@ \n",CENTRAL_NAME,textField.text];
        NSData *data = [contentWillSend dataUsingEncoding:NSUTF8StringEncoding];
        
        [_targetPeripheral writeValue:data forCharacteristic:_targetCharactistic type:CBCharacteristicWriteWithResponse];
        
    }

    return false;
}

#pragma mark - CBPeripheralDelegate Methods

- (void) peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error {
    
    NSString *content = [[NSString alloc] initWithData:characteristic.value encoding:NSUTF8StringEncoding];
    
    if(content.length>0)
    {
        _logTextView.text = [NSString stringWithFormat:@"%@%@",content,_logTextView.text];
    }
}

- (void) peripheral:(CBPeripheral *)peripheral didWriteValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error {
    
    if(error!=nil)
    {
        NSLog(@"didWriteValueForCharacteristic error: %@",error.description);
    }
}


@end
