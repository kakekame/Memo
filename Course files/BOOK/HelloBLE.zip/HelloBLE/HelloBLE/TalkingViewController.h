//
//  TalkingViewController.h
//  HelloBLE
//
//  Created by Kent Liu on 2015/8/12.
//  Copyright (c) 2015年 Kent Liu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>

@interface TalkingViewController : UIViewController

@property (nonatomic,strong) CBPeripheral *targetPeripheral;
@property (nonatomic,strong) CBCharacteristic *targetCharactistic;

@end
