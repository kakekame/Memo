//
//  MasterViewController.m
//  HelloBLE
//
//  Created by Kent Liu on 2015/8/10.
//  Copyright (c) 2015年 Kent Liu. All rights reserved.
//

#import "DiscoveryTableViewController.h"
#import <CoreBluetooth/CoreBluetooth.h>
#import "DiscoveredPeripheral.h"
#import "TalkingViewController.h"

#define TABLEVIEW_RELOAD_INTERVAL   3.0

@interface DiscoveryTableViewController () <CBCentralManagerDelegate,CBPeripheralDelegate>
{
    CBCentralManager *centralManager;
    CBPeripheral *talkingPeripheral;
    CBCharacteristic *talkingCharactistic;
    
    NSMutableDictionary *allDiscovered;
    NSMutableString *peripheralDetailInfoString;
    BOOL shouldStartTalkWhenConnected;
    
    NSDate *lastTableViewReloadDateTime;
    
    NSMutableArray *restServices;
}
@property (weak, nonatomic) IBOutlet UISwitch *scanSwitch;

@end

@implementation DiscoveryTableViewController

- (void)awakeFromNib {
    [super awakeFromNib];
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        self.clearsSelectionOnViewWillAppear = NO;
        self.preferredContentSize = CGSizeMake(320.0, 600.0);
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    centralManager = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
    allDiscovered = [NSMutableDictionary new];
    restServices = [NSMutableArray new];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    
    if(talkingPeripheral != nil)
    {
        [centralManager cancelPeripheralConnection:talkingPeripheral];
        talkingPeripheral = nil;
        talkingCharactistic = nil;
        
        [self startToScan];
    }
}
- (IBAction)scanSwitchChanged:(id)sender {
    
    if(_scanSwitch.on)
    {
        [self startToScan];
    }
    else
    {
        [self stopScanning];
    }
    
}

- (void) showSimpleAlert:(NSString*) title message:(NSString*) message {
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *ok=[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
    
    [alert addAction:ok];
    
    [self presentViewController:alert animated:true completion:nil];
}

#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return allDiscovered.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    
    NSArray *allKeys = allDiscovered.allKeys;
    
    DiscoveredPeripheral *targetItem = allDiscovered[allKeys[indexPath.row]];
    
    NSString *line1String = [NSString stringWithFormat:@"%@ RSSI: %ld",targetItem.peripheral.name,(long)targetItem.lastRSSI];
    NSString *line2String = [NSString stringWithFormat:@"Last Seen: %.1f seconds ago.",[[NSDate date] timeIntervalSinceDate:targetItem.lastSeenDateTime]];

    cell.textLabel.text = line1String;
    cell.detailTextLabel.text = line2String;
    return cell;
}


- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSArray *allKeys = allDiscovered.allKeys;
    
    DiscoveredPeripheral *targetItem = allDiscovered[allKeys[indexPath.row]];
    
    [centralManager connectPeripheral:targetItem.peripheral options:nil];
    
    peripheralDetailInfoString = [NSMutableString string];
    
    shouldStartTalkWhenConnected = true;
    
}

- (void) tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath {
    
    NSArray *allKeys = allDiscovered.allKeys;
    
    DiscoveredPeripheral *targetItem = allDiscovered[allKeys[indexPath.row]];
    
    [centralManager connectPeripheral:targetItem.peripheral options:nil];
    
    peripheralDetailInfoString = [NSMutableString string];
    
    shouldStartTalkWhenConnected = false;
    
}

- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    TalkingViewController *targetVC = segue.destinationViewController;
    
    targetVC.targetPeripheral = talkingPeripheral;
    targetVC.targetCharactistic = talkingCharactistic;
    
}

- (BOOL) shouldPerformSegueWithIdentifier:(NSString *)identifier sender:(id)sender {
    
    return false;
    
}


#pragma mark - Central Methods

- (void) startToScan {
    
    NSArray *services = @[];
    NSDictionary *options = @{CBCentralManagerScanOptionAllowDuplicatesKey:@(true)};
    
    [centralManager scanForPeripheralsWithServices:services
                                           options:options];
    
}

- (void) stopScanning {
    
    [centralManager stopScan];
    
}

#pragma mark - CBCentralManagerDelegate Methods

- (void) centralManagerDidUpdateState:(CBCentralManager *)central {
    
    CBCentralManagerState state = central.state;
    
    if(state != CBCentralManagerStatePoweredOn)
    {
        NSString *message = [NSString stringWithFormat:@"BLE is not available(error: %ld)",(long)state];
        
        [self showSimpleAlert:nil message:message];
    }
}

- (void) centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI {
    
    DiscoveredPeripheral *existItem = allDiscovered[peripheral.identifier.UUIDString];
    
    if(existItem == nil)
    {
        NSLog(@"Discovered %@,RSSI: %ld,UUID: %@",peripheral.name,(long)[RSSI integerValue],peripheral.identifier.UUIDString);
        
    }
    
    DiscoveredPeripheral *newItem = [DiscoveredPeripheral new];
    newItem.peripheral = peripheral;
    newItem.lastRSSI = [RSSI integerValue];
    newItem.lastSeenDateTime = [NSDate date];
    
    // Add to allDiscovered
    [allDiscovered setObject:newItem forKey:peripheral.identifier.UUIDString];

    // Check if should reload tableview
    
    NSDate *now = [NSDate date];
    
    if(existItem == nil || [now timeIntervalSinceDate:lastTableViewReloadDateTime] > TABLEVIEW_RELOAD_INTERVAL)
    {
        lastTableViewReloadDateTime = now;
        
        [self.tableView reloadData];
    }
}

- (void) centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral {
    
    NSLog(@"Peripheral Connected: %@",peripheral.name);
    
    [self stopScanning];
    
    peripheral.delegate = self;
    [restServices removeAllObjects];
    [peripheral discoverServices:nil];
}

- (void) centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error {
    
    [self showSimpleAlert:@"Fail to connect" message:error.description];
    
    [self startToScan];
}

- (void) centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error {
    
    [self startToScan];
    
}

#pragma mark - CBPeripheralDelegate Methods

- (void) peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error {
    
    if(error)
    {
        [centralManager cancelPeripheralConnection:peripheral];
        [self startToScan];
        return;
    }
    
    [restServices addObjectsFromArray:peripheral.services];
    
    // Pick the first one

    CBService *targetService = restServices[0];
    
    [peripheral discoverCharacteristics:nil forService:targetService];
    
    [restServices removeObjectAtIndex:0];
}

- (void) peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error {
    if(error)
    {
        [centralManager cancelPeripheralConnection:peripheral];
        [self startToScan];
        return;
    }
    
    NSString *tmpString = [NSString stringWithFormat:@"*** Peripheral: %@ (%ld services)\n",peripheral.name,(unsigned long)peripheral.services.count];
    
    [peripheralDetailInfoString appendString:tmpString];
    
    tmpString = [NSString stringWithFormat:@"** Service: %@ (%ld characteristics)\n",service.UUID.UUIDString,(unsigned long)service.characteristics.count];
    
    [peripheralDetailInfoString appendString:tmpString];
    
    for(CBCharacteristic *tmp in service.characteristics)
    {
        tmpString = [NSString stringWithFormat:@"* Characteristic: %@ \n",tmp.UUID.UUIDString];
        [peripheralDetailInfoString appendString:tmpString];
        
        if([tmp.UUID.UUIDString hasPrefix:@"888"] && shouldStartTalkWhenConnected)
        {
            [restServices removeAllObjects];
            talkingPeripheral = peripheral;
            talkingCharactistic = tmp;
        }
    }
    
    if(restServices.count == 0)
    {
        if(shouldStartTalkWhenConnected && talkingPeripheral != nil)
        {
            [self performSegueWithIdentifier:@"startTalking" sender:nil];
        }
        else
        {
            [self showSimpleAlert:@"Detail" message:peripheralDetailInfoString];
            
            [centralManager cancelPeripheralConnection:peripheral];
            [self startToScan];
            
            shouldStartTalkWhenConnected = false;
        }
    }
    else
    {
        // Move to next Service
        CBService *targetService = restServices[0];
        
        [peripheral discoverCharacteristics:nil forService:targetService];
        
        [restServices removeObjectAtIndex:0];
    }
    
    
}



@end






