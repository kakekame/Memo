//
//  ViewController.swift
//  SwiftTVOSHelloMoviesPlayer
//
//  Created by Kent Liu on 2016/2/17.
//  Copyright © 2016年 Kent Liu. All rights reserved.
//

import UIKit
import AVFoundation
import AVKit

enum ContentKeys {
    case name
    case url
}

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    @IBOutlet weak var movieListTableView: UITableView!
    @IBOutlet weak var previewPlayerPositionView: UIView!
    @IBOutlet weak var loadingIndicatorView: UIActivityIndicatorView!
    
    var previewPlayer:AVPlayer?
    var previewPlayerLayer:AVPlayerLayer?
    
    var datas = [Dictionary<ContentKeys,String>]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.


        datas.append([.name:"我不願讓你一個人",.url:"http://t.softarts.cc/videos/Mayday_01.mp4"])
        datas.append([.name:"乾杯Cheers",.url:"http://t.softarts.cc/videos/Mayday_02.mp4"])
        datas.append([.name:"入陣曲",.url:"http://t.softarts.cc/videos/Mayday_03.mp4"])
        datas.append([.name:"星空",.url:"http://t.softarts.cc/videos/Mayday_04.mp4"])
        datas.append([.name:"將軍令",.url:"http://t.softarts.cc/videos/Mayday_05.mp4"])
        datas.append([.name:"盛夏光年",.url:"http://t.softarts.cc/videos/Mayday_06.mp4"])
        datas.append([.name:"步步Step by Step",.url:"http://t.softarts.cc/videos/Mayday_07.mp4"])
        datas.append([.name:"Big Buck Bunny",.url:"http://184.72.239.149/vod/smil:bigbuckbunnyiphone.smil/playlist.m3u8"])

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue,
        sender: Any?) {
            let destination = segue.destination as!
            AVPlayerViewController
            let url = URL(string: (sender as? String)!)
            destination.player = AVPlayer(url: url!)
            destination.player?.play()
    }
    
    // MARK: UITableViewDataSource Methods

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return datas.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath)
        
        cell.textLabel!.text = datas[(indexPath as NSIndexPath).row][.name]
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didUpdateFocusIn context: UITableViewFocusUpdateContext, with coordinator: UIFocusAnimationCoordinator) {
        
        let nextIndexPath = context.nextFocusedIndexPath
        
        guard nextIndexPath != nil else {
            return
        }
        
        NSLog("move focus to \((nextIndexPath as NSIndexPath?)?.row)")
        
        let url = URL(string: (datas[(nextIndexPath! as NSIndexPath).row][.url])!)
        
        guard let finalURL = url else
        {
            return
        }
        
        playWithURL(finalURL)
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        performSegue(withIdentifier: "goFullScreen", sender: datas[(indexPath as NSIndexPath).row][.url])
        stopPreviewPlayer()
        
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    func playWithURL(_ url:URL)
    {
        stopPreviewPlayer()
        
        previewPlayer = AVPlayer(url: url)
        previewPlayerLayer = AVPlayerLayer(player: previewPlayer)
        previewPlayerLayer!.frame = previewPlayerPositionView.frame
        previewPlayer?.volume = 0.2
        previewPlayer?.addObserver(self, forKeyPath: "status", options: .new, context: nil)
        self.view.layer.addSublayer(previewPlayerLayer!)
        previewPlayer?.play()
        loadingIndicatorView.startAnimating()
    }
    
    func stopPreviewPlayer() {
        
        if previewPlayer != nil
        {
            previewPlayer?.rate = 0.0
            previewPlayerLayer?.removeFromSuperlayer()
            previewPlayer?.removeObserver(self, forKeyPath: "status")
            previewPlayer = nil
            previewPlayerLayer = nil
            loadingIndicatorView.stopAnimating()
        }
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        
        let player = object as! AVPlayer
        
        if keyPath == "status" && player.status == .readyToPlay{
            NSLog("Ready to Play")
            loadingIndicatorView.stopAnimating()
        }
        
    }

}

