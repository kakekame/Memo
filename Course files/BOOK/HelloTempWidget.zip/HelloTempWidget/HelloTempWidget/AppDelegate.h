//
//  AppDelegate.h
//  HelloTempWidget
//
//  Created by Kent Liu on 2015/10/29.
//  Copyright © 2015年 Kent Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

#define JUMP_TO_NOTIFICATION @"JUMP_TO_NOTIFICATION"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) NSString *jumpToParameter;


@end

