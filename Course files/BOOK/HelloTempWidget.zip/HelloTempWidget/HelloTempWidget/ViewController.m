//
//  ViewController.m
//  HelloTempWidget
//
//  Created by Kent Liu on 2015/10/29.
//  Copyright © 2015年 Kent Liu. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleJumpToNotification:) name:JUMP_TO_NOTIFICATION object:nil];
}

- (void) viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    if(appDelegate.jumpToParameter != nil)
    {
        [self doJumpTo:appDelegate.jumpToParameter];
    }
    
}

- (void) handleJumpToNotification:(NSNotification*) notify
{
    [self doJumpTo:notify.object];
}
- (void) doJumpTo:(NSString*) parameter {
    
    NSString *segueID = [NSString stringWithFormat:@"goFunction%@",parameter];
    [self performSegueWithIdentifier:segueID sender:nil];
    
    // Clear appDelegate.jumpToParameter
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    appDelegate.jumpToParameter = nil;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end





