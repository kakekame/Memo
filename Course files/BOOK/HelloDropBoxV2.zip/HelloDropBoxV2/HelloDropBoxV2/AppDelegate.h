//
//  AppDelegate.h
//  HelloDropBoxV2
//
//  Created by Kent Liu on 2016/10/1.
//  Copyright © 2016年 Kent Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

#define LOGIN_SUCCESS_NOTIFICATION  @"LOGIN_SUCCESS_NOTIFICATION"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

