//
//  MasterViewController.h
//  HelloDropBoxV2
//
//  Created by Kent Liu on 2016/10/1.
//  Copyright © 2016年 Kent Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DetailViewController;

@interface MasterViewController : UITableViewController

@property (strong, nonatomic) DetailViewController *detailViewController;


@end

