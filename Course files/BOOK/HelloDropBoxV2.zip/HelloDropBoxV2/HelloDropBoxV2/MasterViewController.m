//
//  MasterViewController.m
//  HelloDropBoxV2
//
//  Created by Kent Liu on 2016/10/1.
//  Copyright © 2016年 Kent Liu. All rights reserved.
//

#import "MasterViewController.h"
#import "DetailViewController.h"
#import <ObjectiveDropboxOfficial.h>
#import "AppDelegate.h"

@interface MasterViewController ()

@property NSMutableArray *objects;
@end

@implementation MasterViewController
{
    DropboxClient *client;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

    
    self.detailViewController = (DetailViewController *)[[self.splitViewController.viewControllers lastObject] topViewController];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        if([DropboxClientsManager authorizedClient] == nil) {
            // Need to login
            [DropboxClientsManager authorizeFromController:[UIApplication sharedApplication]
                                                controller:self
                                                   openURL:^(NSURL * _Nonnull url) {
                                                       [[UIApplication sharedApplication] openURL:url];
                                                   }
                                               browserAuth:false];
        } else {
            // Logged in already
            [self startDropboxFunction];
        }
        
        
    });
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(startDropboxFunction) name:LOGIN_SUCCESS_NOTIFICATION object:nil];
    
}



- (void)viewWillAppear:(BOOL)animated {
    self.clearsSelectionOnViewWillAppear = self.splitViewController.isCollapsed;
    [super viewWillAppear:animated];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) startDropboxFunction {
    
    self.navigationItem.leftBarButtonItem = self.editButtonItem;
    
    UIBarButtonItem *addButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(insertNewObject:)];
    self.navigationItem.rightBarButtonItem = addButton;
    
    client = [DropboxClientsManager authorizedClient];
    
    [self downloadFileList];
}

- (void) downloadFileList {
    
    if (!self.objects) {
        self.objects = [[NSMutableArray alloc] init];
    } else {
        [_objects removeAllObjects];
    }
    
    [[client.filesRoutes listFolder:@""] response:^(DBFILESListFolderResult * _Nullable results, DBFILESListFolderError * _Nullable error, DBError * _Nullable dbError) {
        
        NSLog(@"Total %ld files.",results.entries.count);
        
        for(DBFILESMetadata *tmp in results.entries) {
            // ...
            [_objects addObject:tmp.name];
        }
        
        [self.tableView reloadData];
    }];
    
}


- (void)insertNewObject:(id)sender {
    
    NSURL *sourceFileURL = [[NSBundle mainBundle] URLForResource:@"jobs_monkey.jpg" withExtension:nil];

    NSString *fullFileName = [NSString stringWithFormat:@"/%@.jpg",[NSDate date]];

    [[client.filesRoutes uploadUrl:fullFileName inputUrl:sourceFileURL] response:^(DBFILESFileMetadata * _Nullable metaData, DBFILESUploadError * _Nullable error, DBError * _Nullable dbError) {
       
        if(metaData) {
            NSLog(@"Upload successfully!: %@",metaData);
            [self downloadFileList];
        } else {
            NSLog(@"Upload Fail: %@",error);
        }
        
    }];

}


#pragma mark - Segues

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([[segue identifier] isEqualToString:@"showDetail"]) {
        NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
        NSString *fileName = self.objects[indexPath.row];
        DetailViewController *controller = (DetailViewController *)[[segue destinationViewController] topViewController];
        [controller setDetailItem:fileName];
        controller.navigationItem.leftBarButtonItem = self.splitViewController.displayModeButtonItem;
        controller.navigationItem.leftItemsSupplementBackButton = YES;
    }
}


#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.objects.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];

    cell.textLabel.text = self.objects[indexPath.row];
    return cell;
}


- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}


- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {

        NSString *fileName = [NSString stringWithFormat:@"/%@",_objects[indexPath.row]];
        
[[client.filesRoutes delete_:fileName] response:^(DBFILESMetadata * _Nullable metaData, DBFILESDeleteError * _Nullable error, DBError * _Nullable dbError) {
    
    if(metaData) {
        NSLog(@"Delete successfully!: %@",metaData);
        [self downloadFileList];
    } else {
        NSLog(@"Delete Fail: %@",error);
    }
    
}];
        
        
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
    }
}


@end
