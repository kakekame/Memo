//
//  HelloEncodeDecodeViewController.m
//  HelloEncodeDecode
//
//  Created by Liu Kent on 2011/4/7.
//  Copyright 2011年 SoftArt Laboratory. All rights reserved.
//

#import "HelloEncodeDecodeViewController.h"

#import "NSData+MBBase64.h"
#import "NSData+AESAdditions.h"

@implementation HelloEncodeDecodeViewController


- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (IBAction) ToBase64
{
    NSData *dataOriginal=[textFieldSource.text dataUsingEncoding:NSUTF8StringEncoding];
    NSString *stringBase64=[dataOriginal base64Encoding];
    
    textFieldResult.text=stringBase64;
    
}
- (IBAction) FromBase64
{
    NSString *stringBase64=textFieldSource.text;
    NSData *dataOriginal=[NSData dataWithBase64EncodedString: stringBase64];
    
    textFieldResult.text=[[NSString alloc] initWithData:dataOriginal encoding:NSUTF8StringEncoding];
    
}
- (IBAction) Encrypt
{
    NSData *dataOriginal=[textFieldSource.text dataUsingEncoding:NSUTF8StringEncoding];
    NSData *dataEncrypted=[dataOriginal AES128EncryptWithKey: textFieldAESKey.text];
    NSString *stringBase64=[dataEncrypted base64Encoding];
    textFieldResult.text=stringBase64;
    
}
- (IBAction) Decrypt
{
    NSString *stringBase64=textFieldSource.text;
    NSData *dataEncrypted=[NSData dataWithBase64EncodedString: stringBase64];

    NSData *dataDecrypted=[dataEncrypted AES128DecryptWithKey: textFieldAESKey.text];
    textFieldResult.text=[[NSString alloc] initWithData:dataDecrypted encoding:NSUTF8StringEncoding];
    
}

@end
