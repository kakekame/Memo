//
//  HelloEncodeDecodeAppDelegate.h
//  HelloEncodeDecode
//
//  Created by Liu Kent on 2011/4/7.
//  Copyright 2011年 SoftArt Laboratory. All rights reserved.
//

#import <UIKit/UIKit.h>

@class HelloEncodeDecodeViewController;

@interface HelloEncodeDecodeAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, strong) IBOutlet UIWindow *window;

@property (nonatomic, strong) IBOutlet HelloEncodeDecodeViewController *viewController;

@end
