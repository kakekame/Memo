//
//  HelloEncodeDecodeViewController.h
//  HelloEncodeDecode
//
//  Created by Liu Kent on 2011/4/7.
//  Copyright 2011年 SoftArt Laboratory. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HelloEncodeDecodeViewController : UIViewController <UITextFieldDelegate>{
    IBOutlet UITextField *textFieldSource;
    IBOutlet UITextField *textFieldResult;
    IBOutlet UITextField *textFieldAESKey;    
}

- (IBAction) ToBase64;
- (IBAction) FromBase64;
- (IBAction) Encrypt;
- (IBAction) Decrypt;

@end
