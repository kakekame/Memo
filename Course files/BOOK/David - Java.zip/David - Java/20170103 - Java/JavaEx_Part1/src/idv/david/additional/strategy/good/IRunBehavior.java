package idv.david.additional.strategy.good;

public interface IRunBehavior {
	void run();
}
