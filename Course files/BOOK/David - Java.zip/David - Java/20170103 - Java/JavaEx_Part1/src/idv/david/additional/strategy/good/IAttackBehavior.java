package idv.david.additional.strategy.good;

public interface IAttackBehavior {
	void attack();
}
