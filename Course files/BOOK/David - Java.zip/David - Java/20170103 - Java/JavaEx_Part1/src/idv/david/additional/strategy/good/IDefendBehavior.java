package idv.david.additional.strategy.good;

public interface IDefendBehavior {
	void defend();
}
