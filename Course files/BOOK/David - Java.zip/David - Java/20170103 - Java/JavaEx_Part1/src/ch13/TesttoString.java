package ch13;

public class TesttoString {

    public static void main (String args[]) {

      HelloWorld obj = new HelloWorld();
      System.out.println(obj); //會自動執行HelloWorld的toString()方法
    
    }
}
