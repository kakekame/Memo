package ch11;

public class InkBrush {
	public void write() {
		System.out.println("用毛筆寫字");
	}
}
