package ch11;

public interface IWritable {
	void write();
}
