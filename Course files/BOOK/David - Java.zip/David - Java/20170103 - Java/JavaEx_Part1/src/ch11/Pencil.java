package ch11;

public class Pencil {
	public void write() {
		System.out.println("用鉛筆寫字");
	}
}
