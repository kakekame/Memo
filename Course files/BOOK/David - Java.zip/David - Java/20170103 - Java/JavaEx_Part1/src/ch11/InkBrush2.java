package ch11;

public class InkBrush2 implements IWritable {
	public void write() {
		System.out.println("用毛筆寫字");
	}

}
