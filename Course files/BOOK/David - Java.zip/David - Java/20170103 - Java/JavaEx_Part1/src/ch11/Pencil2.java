package ch11;

public class Pencil2 implements IWritable {
	public void write() {
		System.out.println("用鉛筆寫字");
	}

}
