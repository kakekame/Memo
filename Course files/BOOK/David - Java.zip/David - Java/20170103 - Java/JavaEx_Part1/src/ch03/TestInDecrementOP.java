package ch03;
/*
 * 此範例為測試遞增/遞減運算子
 */
public class TestInDecrementOP {

	public static void main(String[] args) {
		int num1 = 3, num2 = 4;
		System.out.println(num1++); 
		System.out.println(++num1); 
		System.out.println(--num2); 
		System.out.println(num2--); 
		System.out.println(num1);   
		System.out.println(num2);  
	}

}
