package ch12;

import static java.lang.System.out;

public class TestStaticImport {

	public static void main(String[] args) {
		//可省略System.
		out.println("看起來有點不習慣...");
	}

}
