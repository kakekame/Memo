//
//  ViewController.m
//  HelloiBeacon
//
//  Created by Kent Liu on 2015/8/10.
//  Copyright (c) 2015年 Kent Liu. All rights reserved.
//

#import "ViewController.h"
#import <CoreLocation/CoreLocation.h>

@interface ViewController () <CLLocationManagerDelegate>
{
    CLLocationManager* locationManager;
    CLBeaconRegion *beaconRegion1;
    CLBeaconRegion *beaconRegion2;
    CLBeaconRegion *beaconRegion3;
}
@property (weak, nonatomic) IBOutlet UILabel *beacon1Label;
@property (weak, nonatomic) IBOutlet UILabel *beacon2Label;
@property (weak, nonatomic) IBOutlet UILabel *beacon3Label;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    NSUUID *beacon1UUID = [[NSUUID alloc] initWithUUIDString:@"94278BDA-B644-4520-8F0C-720EAF059935"];
    NSUUID *beacon2UUID = [[NSUUID alloc] initWithUUIDString:@"84278BDA-B644-4520-8F0C-720EAF059935"];
    NSUUID *beacon3UUID = [[NSUUID alloc] initWithUUIDString:@"64278BDA-B644-4520-8F0C-720EAF059935"];
    
    // Prepare LocationManager
    locationManager=[CLLocationManager new];
    locationManager.delegate = self;
    
    if([locationManager respondsToSelector:@selector(requestAlwaysAuthorization)])
    {
        [locationManager requestAlwaysAuthorization];
    }

    // Prepare beaconRegions
    beaconRegion1 = [[CLBeaconRegion alloc] initWithProximityUUID:beacon1UUID identifier:@"com.kent.beacon1"];
    beaconRegion1.notifyOnEntry = true;
    beaconRegion1.notifyOnExit = true;
    
    beaconRegion2 = [[CLBeaconRegion alloc] initWithProximityUUID:beacon2UUID identifier:@"com.kent.beacon2"];
    beaconRegion2.notifyOnEntry = true;
    beaconRegion2.notifyOnExit = true;
    
    beaconRegion3 = [[CLBeaconRegion alloc] initWithProximityUUID:beacon3UUID identifier:@"com.kent.beacon3"];
    beaconRegion3.notifyOnEntry = true;
    beaconRegion3.notifyOnExit = true;
    

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)switchValueChanged:(id)sender {
    
    if([sender isOn])
    {
        [locationManager startMonitoringForRegion:beaconRegion1];
        [locationManager startMonitoringForRegion:beaconRegion2];
        [locationManager startMonitoringForRegion:beaconRegion3];
//        [locationManager startUpdatingLocation];
    }
    else {
    
        [locationManager stopMonitoringForRegion:beaconRegion1];
        [locationManager stopRangingBeaconsInRegion:beaconRegion1];
        
        [locationManager stopMonitoringForRegion:beaconRegion2];
        [locationManager stopRangingBeaconsInRegion:beaconRegion2];
        
        [locationManager stopMonitoringForRegion:beaconRegion3];
        [locationManager stopRangingBeaconsInRegion:beaconRegion3];
        
        [locationManager stopUpdatingLocation];
    }
}

- (void) showLocalNotificationWithMessage:(NSString*)message
{
    NSLog(@"%@",message);
    
    UILocalNotification *notification = [UILocalNotification new];
    notification.fireDate = [NSDate dateWithTimeIntervalSinceNow:1.0];
    notification.alertBody = message;
    [[UIApplication sharedApplication] scheduleLocalNotification:notification];
}

#pragma mark - CLLocationManagerDelegate Methods

- (void) locationManager:(CLLocationManager *)manager didStartMonitoringForRegion:(CLRegion *)region {
    
    [locationManager requestStateForRegion:region];
    
}

- (void) locationManager:(CLLocationManager *)manager didDetermineState:(CLRegionState)state forRegion:(CLRegion *)region {
    
    NSString *message = nil;
    
    if(state == CLRegionStateInside) {
        message = [NSString stringWithFormat:@"Beacon inside region: %@",region.identifier];
        [locationManager startRangingBeaconsInRegion:(CLBeaconRegion*)region];
    }
    else
    {
        message = [NSString stringWithFormat:@"Beacon outside region: %@",region.identifier];
        [locationManager stopRangingBeaconsInRegion:(CLBeaconRegion*)region];
    }
    
    [self showLocalNotificationWithMessage:message];
}


- (void) locationManager:(CLLocationManager *)manager didEnterRegion:(CLRegion *)region {
    // ...
    
    NSString *message = [NSString stringWithFormat:@"Beacon didEnterRegion : %@",region.identifier];
    
    [self showLocalNotificationWithMessage:message];
}

- (void) locationManager:(CLLocationManager *)manager didExitRegion:(CLRegion *)region {
    NSString *message = [NSString stringWithFormat:@"Beacon didExitRegion : %@",region.identifier];
    
    [self showLocalNotificationWithMessage:message];
}


- (void) locationManager:(CLLocationManager *)manager didRangeBeacons:(NSArray *)beacons inRegion:(CLBeaconRegion *)region {
    
    if(beacons.count == 0)
        return;
    else if(beacons.count > 1)
    {
        NSLog(@"More than one.");
    }

    for(CLBeacon *beacon in beacons)
    {
        NSString *proximityString;
        
        switch (beacon.proximity) {
            case CLProximityUnknown:
                proximityString = @"Unknown";
                break;
            case CLProximityImmediate:
                proximityString = @"Immediate";
                break;
            case CLProximityNear:
                proximityString = @"Near";
                break;
            case CLProximityFar:
                proximityString = @"Far";
                break;
            default:
                proximityString = @"Unknown2";
                break;
        }
        
        NSString *infoString = [NSString stringWithFormat:@"%@ ,RSSI:%ld,%@",region.identifier,(long)beacon.rssi,proximityString];
        
        if([region.identifier isEqualToString:beaconRegion1.identifier])
        {
            _beacon1Label.text = infoString;
        }
        else if([region.identifier isEqualToString:beaconRegion2.identifier])
        {
            _beacon2Label.text = infoString;
        }
        else if([region.identifier isEqualToString:beaconRegion3.identifier])
        {
            _beacon3Label.text = infoString;
        }
    }
    
}

@end







