//
//  ViewController.swift
//  SwiftHelloApplePay
//
//  Created by Kent Liu on 2017/2/08.
//  Copyright © 2017年 Kent Liu. All rights reserved.
//

import UIKit
import PassKit



class ViewController: UIViewController,PKPaymentAuthorizationViewControllerDelegate {
    @IBOutlet weak var productNameLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var buyWithApplePayBtn: UIButton!
    
    let supportedPaymentNetworks:[PKPaymentNetwork] = [.visa,.masterCard,.JCB,.chinaUnionPay]
    let merchantID = "merchant.com.ap104.applepay"
    
    let shippingName = "運費"
    let productName = "啃得雞個人餐"
    let productPrice = "88"
    var paymentSuccess = false
    var shippingFee = 0
    var summaryItems = [PKPaymentSummaryItem]()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        // Show Product Info
        productNameLabel.text = productName
        priceLabel.text = "NTD\(productPrice)"
        
        // Check if this device support Apple Pay or not
        guard PKPaymentAuthorizationViewController.canMakePayments() else {
            DispatchQueue.main.async {
                // Hide the Apple Pay button
                self.buyWithApplePayBtn.isHidden = true
                self.showMessage(message: "This device don't support Apple Pay.")
            }
            return
        }
        
 
    }
    
    override func viewDidAppear(_ animated: Bool) {
        // Check if this device support Apple Pay for these networks
        guard PKPaymentAuthorizationViewController.canMakePayments(usingNetworks: supportedPaymentNetworks) else {

            let alert = UIAlertController(title: nil, message: "This device don't support valid card.", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
            let setup = UIAlertAction(title: "Setup", style: .default, handler: { (action) in
                // Jump to setup page
                PKPassLibrary().openPaymentSetup()
            })
            alert.addAction(ok)
            alert.addAction(setup)
            
            self.present(alert, animated: true, completion: nil)
            return
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func showMessage(message:String) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(ok)
        
        self.present(alert, animated: true, completion: nil)
    }

    @IBAction func buyWithApplePayBtnPressed(_ sender: Any) {
        
        let request = PKPaymentRequest()
        
        // Assign basic information
        // US,USD
        // CN,CNY
        // TW,TWD
        request.merchantIdentifier = merchantID
        request.countryCode = "TW"
        request.currencyCode = "TWD"
        request.supportedNetworks = supportedPaymentNetworks
        request.merchantCapabilities = .capability3DS
        
        // Assign product items
        let item = PKPaymentSummaryItem.init(label: productName, amount: NSDecimalNumber(string:productPrice), type: .final)
        summaryItems.append(item)

        // Assign Shipping Methods
        let shippingMethod1 = PKShippingMethod(label: "郵局快捷", amount: NSDecimalNumber(string:"30"))
        shippingMethod1.identifier = "EMS"
        shippingMethod1.detail = "兩個工作天到達"
        let shippingMethod2 = PKShippingMethod(label: "黑貓宅配", amount: NSDecimalNumber(string:"80"))
        shippingMethod2.identifier = "BlackCat"
        shippingMethod2.detail = "隔天送達"
        request.shippingMethods = [shippingMethod1,shippingMethod2]
        summaryItems.append(PKPaymentSummaryItem.init(label: shippingName, amount: shippingMethod1.amount, type: .final))
        
        // Assign Bill Information
        request.requiredBillingAddressFields = .all
        
        // Assign Shipping Info
        request.requiredShippingAddressFields = .all
        
        // Prepare Name
        var name = PersonNameComponents()
        name.givenName = "Steve"
        name.familyName = "Jobs"
        
        // Prepare Address
        let address = CNMutablePostalAddress()
        address.street = "館前路45號"
        address.city = "台北市"
        address.postalCode = "101"
        
        // Prepare telephone
        let phone = CNPhoneNumber(stringValue:"0988888888")
        
        // Assign Contact Info
        let contact = PKContact()
        contact.name = name
        contact.postalAddress = address
        contact.phoneNumber = phone
        contact.emailAddress = "stevejobs@apple.com"
        
        request.billingContact = contact
        request.shippingContact = contact
        
        request.paymentSummaryItems = summaryItems

        // Ask Authorization
        let vc = PKPaymentAuthorizationViewController(paymentRequest: request)
        vc.delegate = self
        self.present(vc, animated: true, completion: nil)
    }
    
    // MARK: - PKPaymentAuthorizationViewControllerDelegate Methods
    func paymentAuthorizationViewController(_ controller: PKPaymentAuthorizationViewController, didAuthorizePayment payment: PKPayment, completion: @escaping (PKPaymentAuthorizationStatus) -> Void) {
        
        let tokenData = payment.token.paymentData
        
        print("Payment Token: \(tokenData)")
        
        paymentSuccess = true
        // Send token to server and check if it is success or not.
        
        
        completion(.success)
        
    }
    
    func paymentAuthorizationViewControllerDidFinish(_ controller: PKPaymentAuthorizationViewController) {
        
        controller.dismiss(animated: true, completion: nil)
        
        controller.dismiss(animated: true) { 
            self.showMessage(message: (self.paymentSuccess ? "Authorize Done!":"Authorize not finish."))
        }
    }
    
    func paymentAuthorizationViewController(_ controller: PKPaymentAuthorizationViewController, didSelect shippingMethod: PKShippingMethod, completion: @escaping (PKPaymentAuthorizationStatus, [PKPaymentSummaryItem]) -> Void) {
        
        summaryItems.removeLast()
        summaryItems.append(PKPaymentSummaryItem.init(label: shippingName, amount: shippingMethod.amount, type: .final))
        
        completion(.success, summaryItems)
    }

}

