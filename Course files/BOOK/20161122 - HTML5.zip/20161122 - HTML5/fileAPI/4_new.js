function doFirst(){
	document.getElementById('myFile').onchange = fileChange;
}
function fileChange(){
	var file = document.getElementById('myFile').files[0];
	var message = 'File Name: '+file.name+'\n';
	message += 'File Size: '+file.size+' byte(s)\n';
	message += 'File Type: '+file.type+'\n';
	message += 'Last Modified: '+file.lastModifiedDate;

	document.getElementById('fileInfo').value = message;

	// file content
	var readFile = new FileReader();
	readFile.readAsText(file);
	readFile.addEventListener('load',function(){
		document.getElementById('fileContent').value = readFile.result;
	},false);
}
window.addEventListener('load',doFirst,false);



