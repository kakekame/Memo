function doFirst(){
	document.getElementById('myFile').onchange = fileChange;
}
function fileChange(){
	var file = document.getElementById('myFile').files[0];
	var message = 'File Name: '+file.name+'\n';
	message += 'File Size: '+file.size+' byte(s)\n';
	message += 'File Type: '+file.type+'\n';
	message += 'Last Modified: '+file.lastModifiedDate;

	document.getElementById('fileInfo').value = message;

	// file content
	var readFile = new FileReader();
	readFile.readAsDataURL(file);
	readFile.addEventListener('load',function(){
		var image = document.getElementById('image');
		image.src = readFile.result;
		image.style.maxWidth = '300px';
		image.style.maxHeight = '500px';
	},false);
}
window.addEventListener('load',doFirst,false);



