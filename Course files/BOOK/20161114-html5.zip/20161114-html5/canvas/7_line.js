function doFirst(){
	var x = document.getElementById('canvas');
	var canvas = x.getContext('2d');

	canvas.lineWidth = 15;
	canvas.strokeStyle = 'red';

	canvas.moveTo(100,100);
	canvas.lineTo(250,100);
	canvas.stroke();

	canvas.beginPath();
	canvas.moveTo(100,130);
	canvas.lineTo(250,130);
	canvas.lineCap = 'round';
	canvas.stroke();

	canvas.beginPath();
	canvas.moveTo(100,160);
	canvas.lineTo(250,160);
	canvas.lineCap = 'square';
	canvas.stroke();

	canvas.lineWidth = 25;
	canvas.strokeStyle = 'red';

	canvas.lineJoin = 'miter';
	canvas.strokeRect(100,250,150,200);

	canvas.lineJoin = 'round';
	canvas.strokeRect(300,250,150,200);

	canvas.lineJoin = 'bevel';
	canvas.strokeRect(500,250,150,200);



}
window.addEventListener('load',doFirst,false);