function doFirst(){
	var x = document.getElementById('canvas');
	var canvas = x.getContext('2d');

	canvas.lineWidth = 5;
	canvas.strokeStyle = 'red';

	canvas.arc(200,200,150,0,Math.PI,false);
	canvas.stroke();	

	canvas.beginPath();
	canvas.arc(600,200,150,0,Math.PI,true);
	canvas.stroke();	

	canvas.beginPath();
	canvas.arc(200,600,150,0,2*Math.PI,true);
	canvas.stroke();	

	canvas.beginPath();
	canvas.arc(600,600,150,0.7*Math.PI,1.8*Math.PI,false);
	canvas.stroke();	

}
window.addEventListener('load',doFirst,false);