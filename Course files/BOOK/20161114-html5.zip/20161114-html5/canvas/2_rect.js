function doFirst(){
	var x = document.getElementById('canvas');
	var canvas = x.getContext('2d');

	canvas.rect(100,100,300,200);
	// canvas.fill();
	canvas.stroke();

	// canvas.fillRect(100,100,300,200);
	// canvas.clearRect(150,150,50,50);

	// canvas.strokeRect(100,100,300,200);
}
window.addEventListener('load',doFirst,false);