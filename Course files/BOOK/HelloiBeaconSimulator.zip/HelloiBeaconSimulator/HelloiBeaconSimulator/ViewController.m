//
//  ViewController.m
//  HelloiBeaconSimulator
//
//  Created by Kent Liu on 2015/8/10.
//  Copyright (c) 2015年 Kent Liu. All rights reserved.
//

#import "ViewController.h"
#import <CoreLocation/CoreLocation.h>
#import <CoreBluetooth/CoreBluetooth.h>

#define UUIDSTRING  @"84278BDA-B644-4520-8F0C-720EAF059935"
#define MAJOR 88
#define MINOR 99

@interface ViewController () <CBPeripheralManagerDelegate,CLLocationManagerDelegate>
{
    CLBeaconRegion *beaconRegion;
    CBPeripheralManager *peripheralManager;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    peripheralManager = [[CBPeripheralManager alloc] initWithDelegate:self queue:nil];

}
- (IBAction)switchValueChanged:(id)sender {
    
    if([sender isOn])
    {
        NSUUID *uuid = [[NSUUID alloc] initWithUUIDString:UUIDSTRING];
        NSString *bundleID = [[NSBundle mainBundle] bundleIdentifier];
        
        beaconRegion = [[CLBeaconRegion alloc] initWithProximityUUID:uuid major:MAJOR minor:MINOR identifier:bundleID];
        
        NSDictionary *datas = [beaconRegion peripheralDataWithMeasuredPower:nil];
        
        [peripheralManager startAdvertising:datas];
    }
    else
    {
        [peripheralManager stopAdvertising];
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) peripheralManagerDidUpdateState:(CBPeripheralManager *)peripheral {
    
    CBManagerState state = peripheral.state;
    
    if(state != CBPeripheralManagerStatePoweredOn)
    {
        NSString *message = [NSString stringWithFormat:@"BLE is not available(error: %ld)",(long)state];
        
        [self showSimpleAlert:nil message:message];
    }
}

- (void) showSimpleAlert:(NSString*) title message:(NSString*) message {
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *ok=[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
    
    [alert addAction:ok];
    
    [self presentViewController:alert animated:true completion:nil];
}

@end
