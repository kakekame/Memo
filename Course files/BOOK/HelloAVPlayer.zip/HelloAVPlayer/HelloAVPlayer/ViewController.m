//
//  ViewController.m
//  HelloAVPlayer
//
//  Created by Kent Liu on 2016/7/20.
//  Copyright © 2016年 Kent Liu. All rights reserved.
//

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>

@interface ViewController ()
{
    AVPlayer *player;
    AVPlayerLayer *playerLayer;
    NSInteger count;
}
@property (weak, nonatomic) IBOutlet UIImageView *resultImageView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    if([segue.identifier isEqualToString:@"goFullScreen"]) {
        
        [self stopBtnPressed:nil];
        
        NSURL *url = [NSURL URLWithString:@"http://184.72.239.149/vod/smil:bigbuckbunnyiphone.smil/playlist.m3u8"];
        
        AVPlayerViewController *vc = segue.destinationViewController;
        vc.player = [[AVPlayer alloc] initWithURL:url];
        [vc.player play];
        
        
    }
}

- (IBAction)playRemoteMovieBtnPressed:(id)sender {
    
    NSURL *url = [NSURL URLWithString:@"http://184.72.239.149/vod/smil:bigbuckbunnyiphone.smil/playlist.m3u8"];
    [self playWithURL:url];
    
}
- (IBAction)playLocalMovieBtnPressed:(id)sender {
    
    NSURL *url = [[NSBundle mainBundle] URLForResource:@"stevejobs_memorial_us.mp4" withExtension:nil];
    [self playWithURL:url];
    
}
- (IBAction)playRemoteMP3BtnPressed:(id)sender {
    
    NSURL *url = [NSURL URLWithString:@"https://dl.dropbox.com/u/12116609/00_KentClass/Sample.mp3"];
    [self playWithURL:url];
}

- (void) playWithURL:(NSURL*) url {
    
    [self stopBtnPressed:nil];
    
    AVPlayerItem *playerItem = [AVPlayerItem playerItemWithURL:url];
    
    player = [[AVPlayer alloc] initWithPlayerItem:playerItem];
    playerLayer = [AVPlayerLayer playerLayerWithPlayer:player];
    
    playerLayer.frame = _resultImageView.frame;
    [self.view.layer addSublayer:playerLayer];
    [player play];
    player.rate = 1.0;

    // Add Observer
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playbackDidFinish) name:AVPlayerItemDidPlayToEndTimeNotification object:nil];
    
}

- (void) playbackDidFinish {
    [self stopBtnPressed:nil];
}
//
//- (void) observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context {
//    
//    if(context == 0) {
//        if(player.rate == 0.0) // Stop!
//        {
//            [player removeObserver:self forKeyPath:@"rate" context:0];
//            
//            // Clear up
//            [playerLayer removeFromSuperlayer]; // Important!
//            player = nil;
//            playerLayer = nil;
//        }
//    }
//}

- (IBAction)getThumbnailBtnPressed:(id)sender {
    
    NSURL *url = [[NSBundle mainBundle] URLForResource:@"stevejobs_memorial_us.mp4" withExtension:nil];
    
    AVURLAsset *asset = [AVURLAsset URLAssetWithURL:url options:nil];
    AVAssetImageGenerator *generator = [AVAssetImageGenerator assetImageGeneratorWithAsset:asset];
    generator.appliesPreferredTrackTransform = true;
    generator.requestedTimeToleranceAfter = kCMTimeZero;
    generator.requestedTimeToleranceBefore = kCMTimeZero;
    
    CGImageRef cgImage = [generator copyCGImageAtTime:CMTimeMake(count, 10) actualTime:nil error:nil];
    
    UIImage *image = [UIImage imageWithCGImage:cgImage];
    
    _resultImageView.image = image;
    
    CGImageRelease(cgImage);
    
    count += 1;
    
    
}
- (IBAction)stopBtnPressed:(id)sender {
    
    if(player != nil) {
        
//        [player removeObserver:self forKeyPath:@"rate" context:0];
        
        player.rate = 0.0;  // 0.5:半速, 1.0:標準速度, 2.0:兩倍速
        
        [playerLayer removeFromSuperlayer]; // Important!
        player = nil;
        playerLayer = nil;
        
        // Remove Observer
        [[NSNotificationCenter defaultCenter] removeObserver:self name:AVPlayerItemDidPlayToEndTimeNotification object:nil];
        
    }
    
}

@end







