//
//  ViewController.h
//  HelloAVPlayer
//
//  Created by Kent Liu on 2016/7/20.
//  Copyright © 2016年 Kent Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

