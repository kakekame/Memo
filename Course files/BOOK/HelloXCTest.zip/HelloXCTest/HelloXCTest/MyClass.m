//
//  MyClass.m
//  HelloXCTest
//
//  Created by Kent Liu on 2015/6/27.
//  Copyright (c) 2015年 Kent Liu. All rights reserved.
//

#import "MyClass.h"

@implementation MyClass

- (NSInteger) plusWithNumber1:(NSInteger)numbe1 number2:(NSInteger)number2 {
    
    return numbe1 + number2;
    
}

- (NSInteger) minusWithNumber1:(NSInteger)numbe1 number2:(NSInteger)number2 {
    
    return numbe1 * number2;
    
}

@end
