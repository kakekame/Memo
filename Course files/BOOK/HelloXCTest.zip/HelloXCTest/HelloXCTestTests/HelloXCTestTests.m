//
//  HelloXCTestTests.m
//  HelloXCTestTests
//
//  Created by Kent Liu on 2015/6/27.
//  Copyright (c) 2015年 Kent Liu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <XCTest/XCTest.h>
#import "MyClass.h"

@interface HelloXCTestTests : XCTestCase

@end

@implementation HelloXCTestTests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample {
    // This is an example of a functional test case.
    
    UIButton *button1 = [UIButton new];
    UIButton *button2 = button1;
    
    XCTAssert(YES, @"測試是否成功");
    XCTAssertEqual(3, 3, @"兩個敘述句或者結果的值是否相等");
    XCTAssertEqualObjects(button1, button2, @"兩個物件是否是同一個物件");
    XCTAssertEqualWithAccuracy(3, 5, 3, @"兩個敘述句或者結果的值是否在誤差範圍內");
    XCTAssertNil(button1, @"需要為 nil 才算成功");
    XCTAssertNotNil(button1, @"需要非 nil 才算成功");
    XCTAssertTrue(true, @"需要為 true 才算成功");
    
    
}

- (void)testPlus {
    // This is an example of a functional test case.
    
    MyClass *class = [MyClass new];
    
    NSInteger result = [class plusWithNumber1:8 number2:3];
    
    XCTAssertEqual(result, 11, @"8 + 3 should be 11.");
    
    XCTAssert(YES, @"Plus Test Pass");
}

- (void)testMinus {
    // This is an example of a functional test case.
    MyClass *class = [MyClass new];
    
    NSInteger result = [class minusWithNumber1:8 number2:3];
    
    XCTAssertEqual(result, 5, @"8 - 3 should be 5.");
    
    XCTAssert(YES, @"Minus Test Pass");
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
