//
//  newsItem.swift
//  SwiftHelloRSSReader
//
//  Created by Kent Liu on 2014/12/19.
//  Copyright (c) 2014年 Kent Liu. All rights reserved.
//

import Foundation

class NewsItem {
    
    init()
    {
        
    }
    
    var title:String?
    var link:String?
    var pubDate:String?
    var description:String?
    
}
