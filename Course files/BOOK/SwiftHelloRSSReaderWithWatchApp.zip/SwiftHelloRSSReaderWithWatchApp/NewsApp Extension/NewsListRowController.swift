//
//  NewsListRowController.swift
//  SwiftHelloRSSReader
//
//  Created by Kent Liu on 2016/2/19.
//  Copyright © 2016年 Kent Liu. All rights reserved.
//

import WatchKit
import Foundation

class NewsListRowController: NSObject {
    @IBOutlet var titleLabel: WKInterfaceLabel!
    @IBOutlet var dateTimeLabel: WKInterfaceLabel!

}
