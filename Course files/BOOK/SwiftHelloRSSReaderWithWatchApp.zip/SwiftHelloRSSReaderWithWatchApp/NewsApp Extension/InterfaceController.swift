//
//  InterfaceController.swift
//  NewsApp Extension
//
//  Created by Kent Liu on 2016/2/19.
//  Copyright © 2016年 Kent Liu. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {
    @IBOutlet var newsTable: WKInterfaceTable!
    
    var datas = [NewsItem]()

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
        
        let defaults = UserDefaults(suiteName: "group.newsApp")
        var url = defaults!.url(forKey: "NewsURL")
        
        // Ref: http://stackoverflow.com/questions/32638667/settings-bundle-not-working-on-watchos-2
        // Since Setting Bundle only work at real devices,use it to work around at simulator
        if url == nil {
            url = URL(string: "http://udn.com/rssfeed/news/1")
        }
        
        // Download News RSS Feed
        
        let requet = URLRequest(url: url!)
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config)
        let task = session.dataTask(with: requet, completionHandler: { (data, response, error) -> Void in
            
            if error != nil {
                NSLog("Download Fail: \(error)")
                return
            }
            let contentString = String(data: data!, encoding: String.Encoding.utf8)
            
            print("Content:" + contentString!)
            //
            let parser = XMLParser(data: data!)
            
            let parserDelegate = MyParserDelegate()
            
            parser.delegate = parserDelegate
            
            let success = parser.parse()
            
            if success
            {
                self.datas = parserDelegate.resultArray

                DispatchQueue.main.async(execute: {
                    
                    self.newsTable.setNumberOfRows(self.datas.count, withRowType: "NewsListRowController")
                    
                    for i in 0..<self.datas.count
                    {
                        let row = self.newsTable.rowController(at: i) as! NewsListRowController
                        let newsItem = self.datas[i]
                        row.titleLabel.setText(newsItem.title)
                        row.dateTimeLabel.setText(newsItem.pubDate)
                    }
                    
                })
                
                
            }
            
        }) 
        task.resume()
        
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    override func contextForSegue(withIdentifier segueIdentifier: String, in table: WKInterfaceTable, rowIndex: Int) -> Any? {
        
        let newsItem = datas[rowIndex]
        
        var description = newsItem.description
        
        if description == nil
        {
            description = ""
        }
        
        return ["Description":description!]
        
    }

}
