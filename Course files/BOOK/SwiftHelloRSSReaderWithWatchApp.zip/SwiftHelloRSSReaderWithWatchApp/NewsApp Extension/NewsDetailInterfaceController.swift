//
//  NewsDetailInterfaceController.swift
//  SwiftHelloRSSReader
//
//  Created by Kent Liu on 2016/2/19.
//  Copyright © 2016年 Kent Liu. All rights reserved.
//

import WatchKit
import Foundation


class NewsDetailInterfaceController: WKInterfaceController {
    @IBOutlet var descriptionLabel: WKInterfaceLabel!
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        let info = context as! [String:String]
        
        // Configure interface objects here.
        descriptionLabel.setText(self.stripHTMLTagWithString(info["Description"]!))
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    func stripHTMLTagWithString(_ input:String) -> String
    {
        let regex = try! NSRegularExpression(pattern: "<.*?>", options: [.caseInsensitive])
        
        let range = NSMakeRange(0, input.characters.count)
        let htmlLessString :String = regex.stringByReplacingMatches(in: input, options: [],
            range:range ,
            withTemplate: "")
        return htmlLessString
    }

}
