function doFirst(){
	var myPosition = new google.maps.LatLng(24.9679029,121.19163080000001);

	// var map = new google.maps.Map(document.getElementById('position'),{
	// 	zoom: 14,
	// 	center: myPosition,
	// 	mapTypeId: google.maps.MapTypeId.ROADMAP
	// });
	
	var area = document.getElementById('position');
	var options = {
		zoom: 14,
		center: myPosition,
		mapTypeId: google.maps.MapTypeId.ROADMAP
	};
	var map = new google.maps.Map(area,options);

	var marker = new google.maps.Marker({
		position: myPosition,
		map: map,
		icon: '../../images/number/dgtp.gif',
		title: '這是中壢中心!'
	});
}
window.addEventListener('load',doFirst,false);

//24.9679411,121.191616




