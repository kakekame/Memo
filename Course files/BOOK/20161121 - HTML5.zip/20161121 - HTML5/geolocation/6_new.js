
function doFirst(){
	navigator.geolocation.getCurrentPosition(succCallback);
}

function succCallback(e){
	var lati = e.coords.latitude;
	var longi = e.coords.longitude;

	document.getElementById('position').innerHTML = '緯度:'+lati+'<br>經度:'+longi;

	var myPosition = new google.maps.LatLng(lati,longi);
	
	var area = document.getElementById('myMap');
	var options = {
		zoom: 14,
		center: myPosition,
		mapTypeId: google.maps.MapTypeId.ROADMAP
	};
	var map = new google.maps.Map(area,options);

	var marker = new google.maps.Marker({
		position: myPosition,
		map: map,
		title: '這是中壢中心!'
	});
}
window.addEventListener('load',doFirst,false);






