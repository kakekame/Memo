//
//  ViewController.m
//  HelloDataProtection
//
//  Created by Kent Liu on 2015/5/30.
//  Copyright (c) 2015年 Kent Liu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

    
    // Put a file at Documents
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    NSLog(@"Documents at : %@",documentsDirectory);
    
    NSDictionary *newObject=@{@"KEY": @"I am a String.",
                              @"DATETIME": [NSDate date]};;
    NSString *fileName=@"test.plist";
    
    NSString *fullFilePathName=[documentsDirectory stringByAppendingPathComponent:fileName];
    
    [newObject writeToFile:fullFilePathName atomically:true];

    // Set Protection
    NSDictionary *attributes = @{NSFileProtectionKey:NSFileProtectionComplete};
    
    NSError *error;
    [[NSFileManager defaultManager] setAttributes:attributes ofItemAtPath:fullFilePathName error:&error];
    
    if(error)
    {
        NSLog(@"error: %@",error.description);
    }

    // Check Data Protection Status
    BOOL bProtectedDataAvailable = [[UIApplication sharedApplication] isProtectedDataAvailable];
    NSLog(@"isProtectedDataAvailable: %@",(bProtectedDataAvailable?@"YES":@"NO"));
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
