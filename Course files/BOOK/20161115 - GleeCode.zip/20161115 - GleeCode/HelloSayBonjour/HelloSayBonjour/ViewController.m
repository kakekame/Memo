//
//  ViewController.m
//  HelloSayBonjour
//
//  Created by 123APP on 2016/11/15.
//  Copyright © 2016年 com.glee. All rights reserved.
//

#import "ViewController.h"
#import "BonjourViewController.h"
@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *nameTextField;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

// 為轉換而準備的方法 （其實是覆寫方法 override）
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    // 我想拿到第二頁的物件
    BonjourViewController * second = segue.destinationViewController;
    // 我想拿到使用者輸入的文字
    NSString * userType = self.nameTextField.text;
    // 將文字帶給第二頁的物件
    second.name = userType;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
