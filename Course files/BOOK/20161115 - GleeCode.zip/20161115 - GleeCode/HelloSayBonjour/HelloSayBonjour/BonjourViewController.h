//
//  BonjourViewController.h
//  HelloSayBonjour
//
//  Created by 123APP on 2016/11/15.
//  Copyright © 2016年 com.glee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BonjourViewController : UIViewController
@property NSString* name;
@end
