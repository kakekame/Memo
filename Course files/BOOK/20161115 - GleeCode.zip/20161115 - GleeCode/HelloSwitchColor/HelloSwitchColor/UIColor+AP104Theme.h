//
//  UIColor+AP104Theme.h
//  HelloSwitchColor
//
//  Created by 123APP on 2016/11/15.
//  Copyright © 2016年 com.glee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (AP104Theme)
+(UIColor*)enterpriseColor;
@end
