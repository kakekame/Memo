//
//  ViewController.m
//  HelloSwitchColor
//
//  Created by 123APP on 2016/11/15.
//  Copyright © 2016年 com.glee. All rights reserved.
//

#import "ViewController.h"
#import "UIColor+AP104Theme.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UISlider *redSlider;
@property (weak, nonatomic) IBOutlet UISlider *greenSlider;
@property (weak, nonatomic) IBOutlet UISlider *blueSlider;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)colorChoosed:(UISlider *)sender {
//    if (sender == self.redSlider) {
//        //
//    } else if (sender == self.greenSlider) {
//        //
//    } else {
//        //
//    }
    
    // 拿三個滑桿的數值，組合成新的顏色
    float red =  self.redSlider.value;
    float green = self.greenSlider.value;
    float blue = self.blueSlider.value;
    NSLog(@"紅色的數值：%f,綠色的數值：%f,藍色的數值：%f",red,green,blue);
    
    //UIColor
    //設定自身畫面的背景色為XX色
    self.view.backgroundColor = [UIColor colorWithRed:red/255.0 green:green/255.0 blue:blue/255.0 alpha:1.0];
    [UIColor enterpriseColor];
    
    
    
    
    
    
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
