<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
<pre>
<?php

	$x=array(
		array(1,3), 
		array(2,5)
	);
	echo $x[0][0]." ";
	echo $x[0][1]."\n";
	echo $x[1][0]." ";
	echo $x[1][1]."\n";

	$x=100;
	echo $x;

	$x="text";
	echo $x.$y;

?>
</pre>
	test...
</body>
</html>