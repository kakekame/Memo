<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
<?php
	print_r($_GET);
?>
<br>
<a href="?action=page1">Link 1</a> | 
<a href="?action=page2">Link 2</a> | 
<a href="?action=page3">Link 3</a>
</body>
</html>