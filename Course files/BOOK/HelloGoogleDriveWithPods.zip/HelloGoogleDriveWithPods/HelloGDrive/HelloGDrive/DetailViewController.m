//
//  DetailViewController.m
//  HelloGDrive
//
//  Created by Kent Liu on 2016/8/2.
//  Copyright © 2016年 Kent Liu. All rights reserved.
//

#import "DetailViewController.h"

@interface DetailViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *resultImageView;

@end

@implementation DetailViewController

#pragma mark - Managing the detail item

- (void)setDetailItem:(id)newDetailItem {
    if (_detailItem != newDetailItem) {
        _detailItem = newDetailItem;
            
        // Update the view.
        [self configureView];
    }
}

- (void)configureView {
    // Update the user interface for the detail item.
    if (self.detailItem && _resultImageView) {

        GTLDriveFile *file = _detailItem;
        
        self.title = file.name;
        
        NSString *urlString = [NSString stringWithFormat:@"https://www.googleapis.com/drive/v2/files/%@?alt=media",file.identifier];
        
        GTMSessionFetcher *fetcher = [_drive.fetcherService fetcherWithURLString:urlString];
        
        [fetcher beginFetchWithCompletionHandler:^(NSData * _Nullable data, NSError * _Nullable error) {
          
            if(error) {
                NSLog(@"Download Fail: %@",error);
            } else {
                _resultImageView.image = [UIImage imageWithData:data];
                
                // Save NSData as a file and place at Documents
                NSURL *documentsURL = [[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask].firstObject;
                
                NSLog(@"Documents: %@",documentsURL.absoluteString);
                
                NSString *fileName = [NSString stringWithFormat:@"File_%@.jpg",[NSDate date]];
                NSURL *fullFileURL = [documentsURL URLByAppendingPathComponent:fileName];
                
                [data writeToURL:fullFileURL atomically:true];
                
            }
        }];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self configureView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
