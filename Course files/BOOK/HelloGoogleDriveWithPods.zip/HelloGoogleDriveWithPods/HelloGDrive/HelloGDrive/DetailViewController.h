//
//  DetailViewController.h
//  HelloGDrive
//
//  Created by Kent Liu on 2016/8/2.
//  Copyright © 2016年 Kent Liu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GTLDrive.h>

@interface DetailViewController : UIViewController

@property (strong,nonatomic) GTLServiceDrive *drive;

@property (strong, nonatomic) id detailItem;
@property (weak, nonatomic) IBOutlet UILabel *detailDescriptionLabel;

@end

