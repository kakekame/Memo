//
//  AppDelegate.h
//  HelloGDrive
//
//  Created by Kent Liu on 2016/8/2.
//  Copyright © 2016年 Kent Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

#define CLIENTID @"422718719418-6gh9ic39f0lj3eretr0qhfprp6fvv6vo.apps.googleusercontent.com"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

