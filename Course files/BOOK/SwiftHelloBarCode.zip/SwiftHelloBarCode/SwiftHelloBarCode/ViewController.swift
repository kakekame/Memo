//
//  ViewController.swift
//  SwiftHelloBarCode
//
//  Created by Kent Liu on 2016/5/29.
//  Copyright © 2016年 Kent Liu. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController,AVCaptureMetadataOutputObjectsDelegate {
    @IBOutlet weak var previewAreaView: UIImageView!
    @IBOutlet weak var enableScanSwitch: UISwitch!

    var session:AVCaptureSession?
    var previewLayer:AVCaptureVideoPreviewLayer?
    var stillImageOutput:AVCaptureStillImageOutput?
    
    let allTypes = [AVMetadataObjectTypeQRCode, AVMetadataObjectTypeCode128Code, AVMetadataObjectTypeCode39Code, AVMetadataObjectTypeCode93Code, AVMetadataObjectTypeUPCECode, AVMetadataObjectTypePDF417Code, AVMetadataObjectTypeEAN13Code, AVMetadataObjectTypeAztecCode]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func scanEnableSwitchValueChanged(_ sender: AnyObject) {
        
        let switchView = sender as! UISwitch
        
        if switchView.isOn {
            
            startToScan()
            
        } else {
            
            stopScanning()
            
        }
        
    }
    
    // MARK: - Scan Session Methods
    func startToScan() {
        
        let captureDevice = AVCaptureDevice.defaultDevice(withMediaType: AVMediaTypeVideo)
        var inputDevice:AVCaptureDeviceInput?
        do {
            // Prepare input and session
            inputDevice = try AVCaptureDeviceInput(device: captureDevice)
        } catch {
            print("Error when prepare input: \(error)")
            enableScanSwitch.isOn = false // Turn off
            return
        }
        
        session = AVCaptureSession()
        session?.addInput(inputDevice)
        
        // Prepare output object
        let captureMetadataOutput = AVCaptureMetadataOutput()
        session?.addOutput(captureMetadataOutput)

        captureMetadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
        captureMetadataOutput.metadataObjectTypes = allTypes
        
        // Prepare Still Image
        stillImageOutput = AVCaptureStillImageOutput()
        
        session!.addOutput(stillImageOutput)
        
        // Prepare Preview Layer
        previewLayer = AVCaptureVideoPreviewLayer(session: session)
        previewLayer?.videoGravity = AVLayerVideoGravityResizeAspectFill
        previewLayer?.frame = previewAreaView.layer.bounds
        previewAreaView.layer.addSublayer(previewLayer!)
        
        // Start Capture
        session?.startRunning()
        
    }
    
    func stopScanning() {
        
        // Stop Capture
        session?.stopRunning()
        session = nil
        
        previewLayer?.removeFromSuperlayer()
        previewLayer = nil
        
        stillImageOutput = nil
    }

    // MARK: - AVCaptureMetadataOutputObjectsDelegate Method
    
    func captureOutput(_ captureOutput: AVCaptureOutput!, didOutputMetadataObjects metadataObjects: [Any]!, from connection: AVCaptureConnection!) {
        
        if metadataObjects == nil || metadataObjects.count == 0 {
            print("No BarCode detected.")
            return
        }
        
        let metadataObj = metadataObjects.first as! AVMetadataMachineReadableCodeObject
        
        if metadataObj.stringValue != nil {
            
            print("Receive String: \(metadataObj.stringValue)")
            
            showStillImage()
            
            // Show Result
            let alert = UIAlertController(title: metadataObj.type, message: metadataObj.stringValue, preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(ok)
            self.present(alert, animated: true, completion: nil)
            
            
            // Stop scanning
            stopScanning()
            enableScanSwitch.isOn = false
        }
        
    }
    
    func showStillImage() {
    
        let stillImageConnection = stillImageOutput!.connection(withMediaType: AVMediaTypeVideo)
        stillImageConnection?.videoOrientation = .portrait
        stillImageConnection?.videoScaleAndCropFactor = 1.0
        stillImageOutput!.captureStillImageAsynchronously(from: stillImageConnection, completionHandler: { (imageDataSampleBuffer, error) in
            if (error != nil) {
                print("There are some error in capturing image")
            } else {
                let jpegData = AVCaptureStillImageOutput.jpegStillImageNSDataRepresentation(imageDataSampleBuffer)
                let image = UIImage(data: jpegData!)!
                
                self.previewAreaView.image = image
                
            }
        })
    }

}

