//
//  ViewController.h
//  HelloMyMultiStoryboard
//
//  Created by Kent Liu on 2016/5/27.
//  Copyright © 2016年 Kent Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

