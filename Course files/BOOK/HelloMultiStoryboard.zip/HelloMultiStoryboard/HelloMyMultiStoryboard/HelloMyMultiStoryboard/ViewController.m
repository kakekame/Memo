//
//  ViewController.m
//  HelloMyMultiStoryboard
//
//  Created by Kent Liu on 2016/5/27.
//  Copyright © 2016年 Kent Liu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)backToMain:(UIStoryboardSegue*)sender {
    
    NSLog(@"backToMain executed.");
    
}

- (IBAction)push1BtnPressed:(id)sender {
    
    UIStoryboard *push = [UIStoryboard storyboardWithName:@"Push" bundle:nil];
    UIViewController* targetVC = [push instantiateViewControllerWithIdentifier:@"yellow"];
    
    targetVC.title = @"Banana";
    
    [self.navigationController pushViewController:targetVC animated:true];
    
}
- (IBAction)modal1BtnPressed:(id)sender {
    
    UIStoryboard *modal = [UIStoryboard storyboardWithName:@"Modal" bundle:nil];
    UIViewController* targetVC = [modal instantiateViewControllerWithIdentifier:@"green"];
    
    [self presentViewController:targetVC
                       animated:true
                     completion:nil];
    
}

@end






