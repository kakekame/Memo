//
//  HelloURLSchemeViewController.h
//  HelloURLScheme
//
//  Created by Liu Kent on 2011/3/30.
//  Copyright 2011年 SoftArt Laboratory. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HelloURLSchemeViewController : UIViewController {
    
}

-(IBAction) launchURLScheme:(id)sender;

@end
