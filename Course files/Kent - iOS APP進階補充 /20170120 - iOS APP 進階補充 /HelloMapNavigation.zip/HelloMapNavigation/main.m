//
//  main.m
//  HelloMapNavigation
//
//  Created by Liu Kent on 2011/3/6.
//  Copyright 2011 SoftArt Lab. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
