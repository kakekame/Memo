//
//  AppDelegate.h
//  HelloLocalAuthentication
//
//  Created by Kent Liu on 2014/11/18.
//  Copyright (c) 2014年 Kent Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

