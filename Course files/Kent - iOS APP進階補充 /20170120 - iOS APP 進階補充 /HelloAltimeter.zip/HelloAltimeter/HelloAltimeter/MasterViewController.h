//
//  MasterViewController.h
//  HelloAltimeter
//
//  Created by Kent Liu on 2014/11/19.
//  Copyright (c) 2014年 Kent Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DetailViewController;

@interface MasterViewController : UITableViewController

@property (strong, nonatomic) DetailViewController *detailViewController;


@end

