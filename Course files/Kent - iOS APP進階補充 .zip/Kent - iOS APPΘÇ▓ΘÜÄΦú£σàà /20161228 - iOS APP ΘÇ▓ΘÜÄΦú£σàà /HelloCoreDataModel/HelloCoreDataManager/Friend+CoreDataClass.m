//
//  Friend+CoreDataClass.m
//  HelloCoreDataManager
//
//  Created by Kent Liu on 2016/10/5.
//  Copyright © 2016年 Kent Liu. All rights reserved.
//

#import "Friend+CoreDataClass.h"

@implementation Friend

@end
