//
//  NewsItem.m
//  HelloRSSReader
//
//  Created by Kent Liu on 2016/3/9.
//  Copyright © 2016年 Kent Liu. All rights reserved.
//

#import "NewsItem.h"

@implementation NewsItem

@end
