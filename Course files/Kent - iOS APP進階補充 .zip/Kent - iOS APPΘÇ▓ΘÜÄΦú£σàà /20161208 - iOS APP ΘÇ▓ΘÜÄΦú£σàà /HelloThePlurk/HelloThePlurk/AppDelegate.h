//
//  AppDelegate.h
//  HelloThePlurk
//
//  Created by Kent Liu on 2015/9/9.
//  Copyright (c) 2015年 Kent Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

