//
//  MyCollectionViewCell.swift
//  SwiftHelloCollectionView
//
//  Created by Kent Liu on 2014/11/29.
//  Copyright (c) 2014年 Kent Liu. All rights reserved.
//

import UIKit

class MyCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var theImageView: UIImageView!
    @IBOutlet weak var theLabel: UILabel!
    
}
