//
//  MyImageAnnotationView.h
//  HelloMap
//
//  Created by Kent Liu on 2015/1/8.
//  Copyright (c) 2015年 Kent Liu. All rights reserved.
//

#import <MapKit/MapKit.h>

@interface MyImageAnnotationView : MKAnnotationView

@end
