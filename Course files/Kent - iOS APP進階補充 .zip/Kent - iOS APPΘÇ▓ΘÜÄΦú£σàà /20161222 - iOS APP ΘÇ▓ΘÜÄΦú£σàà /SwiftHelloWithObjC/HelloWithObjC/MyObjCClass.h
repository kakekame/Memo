//
//  MyObjCClass.h
//  HelloWithObjC
//
//  Created by Kent Liu on 2015/2/8.
//  Copyright (c) 2015年 Kent Liu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyObjCClass : NSObject

@property (nonatomic,strong) NSDate *date;

- (NSString*) sayHello;

@end
