//
//  Communicator.h
//  HelloMySendMessage
//
//  Created by Kent Liu on 2016/6/17.
//  Copyright © 2016年 Kent Liu. All rights reserved.
//

#import <Foundation/Foundation.h>

#define GROUP_NAME  @"AP104"
#define MY_NAME @"Kent紛絲團2"

#define ID_KEY    @"id"
#define USER_NAME_KEY    @"UserName"
#define MESSAGE_KEY    @"Message"
#define DEVICETOKEN_KEY    @"DeviceToken"
#define GROUP_NAME_KEY    @"GroupName"
#define LAST_MESSAGE_ID_KEY    @"LastMessageID"
#define TYPE_KEY    @"Type"
#define DATA_KEY    @"data"
#define MESSAGES_KEY    @"Messages"



typedef void (^DoneHandler)(NSError *error,id result);

@interface Communicator : NSObject

+ (instancetype) sharedInstance;

//- (void) updateDeviceToken:(NSString*) deviceToken
//                completion:(void (^)(NSError *error,id result)) doneHandler;
- (void) updateDeviceToken:(NSString*) deviceToken
                completion:(DoneHandler) doneHandler;

- (void) sendTextMessage:(NSString*) message
            completion:(DoneHandler) doneHandler;

- (void) retriveMessagesWithLastMessageID:(NSInteger) lastMessageID completion:(DoneHandler) doneHandler;

- (void) downloadPhotoWithFileName:(NSString*) fileName
                        completion:(DoneHandler) doneHandler;

- (void) sendPhotoMessageWithData:(NSData*)data
                       completion:(DoneHandler) doneHandler;

@end






