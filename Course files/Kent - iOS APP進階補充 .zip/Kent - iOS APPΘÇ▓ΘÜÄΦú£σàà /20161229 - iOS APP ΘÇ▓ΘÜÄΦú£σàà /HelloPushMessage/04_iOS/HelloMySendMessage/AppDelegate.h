//
//  AppDelegate.h
//  HelloMySendMessage
//
//  Created by Kent Liu on 2016/6/17.
//  Copyright © 2016年 Kent Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

#define DID_RECEIVED_REMOTE_NOTIFICATION @"DID_RECEIVED_REMOTE_NOTIFICATION"


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

