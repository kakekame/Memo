<?php $dbhost 	= "localhost";
$dbuser 	= "root";
$dbpasswd 	= "xxxx";
$dbname 	= "PushMessage";
?>