HTML5-Game-Dev
==============

利用HTML5開發小遊戲       

ref: The Essential Guide to HTML5 - Using Games to Learn HTML5 and JavaScript

投影片：       
1. <a href="http://www.slideshare.net/azole/javascript-html5-0-basic" target="_blank">基礎概念</a>         
2. <a href="http://www.slideshare.net/azole/javascript-html51" target="_blank">骰子遊戲</a>        
3. <a href="http://www.slideshare.net/azole/javascript-html5-2-ball" target="_blank">彈力球</a>         
